using System.Globalization;
using System.Net;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using Microsoft.Data.Sqlite;
using Tablix.Core.Helpers;
using Tablix.Core.Settings;

namespace Tablix.Deployment;

public static partial class Program
{
    public static Task<int> Main(string[] args) => RunAsync(args, Console.In, Console.Out, Console.Error);

    public static async Task<int> RunAsync(string[] args, TextReader input, TextWriter output, TextWriter error,
        IReadOnlyDictionary<string, string>? environment = null)
    {
        try
        {
            var options = Options.Parse(args);
            environment ??= Environment.GetEnvironmentVariables().Cast<System.Collections.DictionaryEntry>()
                .ToDictionary(e => (string)e.Key, e => (string)e.Value!);
            switch (options.Command)
            {
                case "prepare-config": PrepareConfig(options.Base); break;
                case "resolve-deployment":
                    Fields(Resolve(options, ReadSnapshot(await input.ReadToEndAsync()), environment), output); break;
                case "fields": Fields(ReadDeployment(options.Base), output); break;
                case "guard": Guard(options, ReadSnapshot(await input.ReadToEndAsync()), output); break;
                case "initialize-state-file": InitializeFile(options.Base, output); break;
                case "prepare-state": PrepareState(options.Base); break;
                case "register": await Register(options, error); break;
                case "production-prepare": await PrepareProduction(options, environment, error); break;
                case "production-verify": await VerifyProduction(options, environment, error); break;
                default: throw new SetupException("Unknown deployment command.");
            }
            return 0;
        }
        catch (SetupException ex) { await error.WriteLineAsync("ERROR: " + ex.Message); return 1; }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or JsonException or ArgumentException
            or InvalidOperationException or SqliteException or HttpRequestException or OperationCanceledException or FormatException or OverflowException)
        {
            await error.WriteLineAsync("ERROR: Deployment operation failed; check configuration, ownership, stopped containers and service logs. Secret details were not logged.");
            return 1;
        }
    }

    private sealed class SetupException(string message) : Exception(message);
    private sealed record Options(string Command, string Base, string HostBase, bool Stop, string? Url, int Timeout)
    {
        public static Options Parse(string[] args)
        {
            if (args.Length == 0) throw new SetupException("A deployment command is required.");
            string? root = null, host = null, url = null; bool stop = false; int timeout = 60;
            for (int i = 1; i < args.Length; i++)
            {
                if (args[i] == "--stop") { stop = true; continue; }
                if (++i >= args.Length) throw new SetupException("Missing command option value.");
                switch (args[i - 1])
                {
                    case "--base": root = args[i]; break;
                    case "--host-base": host = args[i]; break;
                    case "--url": url = args[i]; break;
                    case "--timeout": timeout = int.Parse(args[i], CultureInfo.InvariantCulture); break;
                    default: throw new SetupException("Unknown command option.");
                }
            }
            if (root is null || timeout < 1 || timeout > 600) throw new SetupException("A package base directory and valid timeout are required.");
            root = Path.GetFullPath(root); host ??= root;
            if (host.IndexOfAny([',', '\r', '\n', '\0']) >= 0 || !host.StartsWith('/'))
                throw new SetupException("Host package path must be an absolute Linux path without commas or newlines.");
            return new(args[0], root, host.TrimEnd('/'), stop, url, timeout);
        }
    }

    private static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = true };
    private static readonly string[] DisabledTools = ["update_context", "update_database_context", "update_table_context"];
    private const string DeploymentFile = "deployment.local.json";
    private const string Label = "com.tablix.offline.package";
    private static JsonObject ReadObject(string path) => JsonNode.Parse(File.ReadAllText(path)) as JsonObject
        ?? throw new SetupException("Configuration must contain a JSON object.");
    private static string Text(JsonNode? node) => node?.GetValue<string>() ?? throw new SetupException("Required configuration text is missing.");
    private static bool IsFalse(JsonNode? node) => node is JsonValue value && value.TryGetValue<bool>(out bool result) && !result;
    private static void Restrict(string path)
    {
        if (!OperatingSystem.IsWindows()) File.SetUnixFileMode(path, UnixFileMode.UserRead | UnixFileMode.UserWrite);
    }
    private static void DirectoryPrivate(string path)
    {
        if (OperatingSystem.IsWindows()) Directory.CreateDirectory(path);
        else Directory.CreateDirectory(path, UnixFileMode.UserRead | UnixFileMode.UserWrite | UnixFileMode.UserExecute);
    }
    private static FileStream CreatePrivate(string path)
    {
        var options = new FileStreamOptions { Mode = FileMode.CreateNew, Access = FileAccess.Write, Share = FileShare.None };
        if (!OperatingSystem.IsWindows()) options.UnixCreateMode = UnixFileMode.UserRead | UnixFileMode.UserWrite;
        return new FileStream(path, options);
    }
    private static void SavePrivate(string path, JsonObject value)
    {
        string temp = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try
        {
            using (var stream = CreatePrivate(temp)) using (var writer = new StreamWriter(stream))
                writer.Write(value.ToJsonString(JsonOptions) + "\n");
            File.Move(temp, path, true); Restrict(path);
        }
        finally { if (File.Exists(temp)) File.Delete(temp); }
    }
    private static JsonObject PrepareConfig(string root)
    {
        DirectoryPrivate(Path.Combine(root, "data")); DirectoryPrivate(Path.Combine(root, "logs"));
        var path = Path.Combine(root, "tablix.json"); bool changed = !File.Exists(path);
        var cfg = ReadObject(changed ? path + ".template" : path);
        if (changed) cfg["ApiKeys"] = new JsonArray(Convert.ToHexString(RandomNumberGenerator.GetBytes(32)).ToLowerInvariant());
        if (!cfg.ContainsKey("Mcp")) { cfg["Mcp"] = new JsonObject(); changed = true; }
        if (cfg["Mcp"] is not JsonObject mcp) throw new SetupException("Mcp must be a settings object.");
        if (!mcp.ContainsKey("ToolNamePrefix")) { mcp["ToolNamePrefix"] = "tablix_"; changed = true; }
        if (!mcp.ContainsKey("DisabledTools")) { mcp["DisabledTools"] = new JsonArray(DisabledTools.Select(t => (JsonNode?)JsonValue.Create(t)).ToArray()); changed = true; }
        try { _ = new McpToolPolicy(mcp.Deserialize<McpSettings>()!); }
        catch (ArgumentException) { throw new SetupException("Invalid MCP prefix or disabled canonical tool suffixes."); }
        if (cfg["ApiKeys"] is not JsonArray keys || keys.Count == 0 || keys.Any(k => k is not JsonValue v || !v.TryGetValue<string>(out var key) || string.IsNullOrWhiteSpace(key) || key == "__REST_API_KEY__"))
            throw new SetupException("tablix.json requires non-empty REST API keys.");
        if (Text(cfg["Persistence"]?["Filename"]) != "/data/tablix.db") throw new SetupException("Persistence.Filename must remain /data/tablix.db.");
        if (cfg["Rest"]?["Port"]?.GetValue<int>() != 9100 || cfg["Rest"]?["McpPort"]?.GetValue<int>() != 9102 || !IsFalse(cfg["Rest"]?["Ssl"]))
            throw new SetupException("Keep container ports 9100/9102 and Ssl=false; configure published ports in deployment.local.json.");
        if (!IsFalse(cfg["Chat"]?["Enabled"])) throw new SetupException("This gateway requires Chat.Enabled=false.");
        if (new[] { "Enable", "OtlpEnable", "PrometheusEnable", "LokiEnable", "ExportLogs" }.Any(k => !IsFalse(cfg["Telemetry"]?[k])))
            throw new SetupException("All telemetry export switches must remain false.");
        if (changed) SavePrivate(path, cfg); else Restrict(path);
        return cfg;
    }

    private static JsonObject Defaults() => new()
    {
        ["ContainerName"] = "tablix-offline", ["BindIp"] = "127.0.0.1", ["RestPort"] = 9100, ["McpPort"] = 7713,
        ["Image"] = "tablix-server:release-20261031", ["ConnectionFiles"] = new JsonArray()
    };
    private static JsonObject ReadDeployment(string root, bool validate = true)
    {
        var cfg = Defaults(); var path = Path.Combine(root, DeploymentFile);
        if (File.Exists(path)) foreach (var item in ReadObject(path)) cfg[item.Key] = item.Value?.DeepClone();
        if (validate) ValidateDeployment(cfg); return cfg;
    }
    private static void ValidateDeployment(JsonObject cfg)
    {
        string rawAddress = Text(cfg["BindIp"]);
        if (!Regex.IsMatch(Text(cfg["ContainerName"]), @"\A[A-Za-z0-9][A-Za-z0-9_.-]*\z") || !IPAddress.TryParse(rawAddress, out var address)
            || rawAddress.Contains('%') || rawAddress.Any(char.IsWhiteSpace)
            || address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork && rawAddress != address.ToString())
            throw new SetupException("Invalid deployment name or numeric IP address.");
        cfg["BindIp"] = address.ToString();
        foreach (string key in new[] { "RestPort", "McpPort" })
        {
            var raw = cfg[key]?.ToString() ?? "";
            if (!Regex.IsMatch(raw, @"\A[0-9]{1,5}\z") || !int.TryParse(raw, out int port) || port < 1 || port > 65535)
                throw new SetupException("Published ports must be integers from 1 to 65535.");
            cfg[key] = port;
        }
        string image = Text(cfg["Image"]);
        if (cfg["RestPort"]!.GetValue<int>() == cfg["McpPort"]!.GetValue<int>() || image.Length == 0 || image.StartsWith('-') || image.Any(char.IsWhiteSpace) || image.Any(char.IsControl)
            || cfg["ConnectionFiles"] is not JsonArray files || files.Any(p => p is not JsonValue v || !v.TryGetValue<string>(out var path) || string.IsNullOrEmpty(path) || path.IndexOfAny(['\r', '\n', '\0']) >= 0))
            throw new SetupException("Invalid deployment ports, image or ConnectionFiles.");
    }
    private static List<JsonObject> ReadSnapshot(string text) => JsonNode.Parse(text) is JsonArray nodes && nodes.All(n => n is JsonObject)
        ? nodes.Select(n => (JsonObject)n!).ToList() : throw new SetupException("Docker inspection must be a JSON array.");
    private static string Name(JsonObject item)
    {
        var name = Text(item["Name"]).TrimStart('/');
        if (!Regex.IsMatch(name, @"\A[A-Za-z0-9][A-Za-z0-9_.-]*\z")) throw new SetupException("Docker returned an invalid container name.");
        return name;
    }
    private static bool Running(JsonObject item) => item["State"]?["Running"]?.GetValue<bool>() == true;
    private static bool UsesState(JsonObject item, string host) => item["Mounts"] is JsonArray mounts && mounts.OfType<JsonObject>().Any(m => m["Source"]?.ToString() == host + "/data");
    private static bool Owned(JsonObject item, string host) => item["Config"]?["Labels"]?[Label]?.ToString() == "true"
        && item["Mounts"] is JsonArray mounts && mounts.OfType<JsonObject>().Where(m => m["Destination"]?.ToString() == "/data").Select(m => m["Source"]?.ToString()).SequenceEqual(new[] { host + "/data" });
    private static void StateAvailable(IEnumerable<JsonObject> snapshot, string host, string desired)
    {
        if (snapshot.Any(c => UsesState(c, host) && Running(c) && Name(c) != desired))
            throw new SetupException("Another running container uses this state directory. Stop its actual Docker name explicitly; no deployment settings were saved.");
    }
    private static JsonArray Published(JsonObject item, int port)
    {
        string key = port + "/tcp";
        if (item["NetworkSettings"]?["Ports"]?[key] is JsonArray a && a.Count > 0) return a;
        if (item["HostConfig"]?["PortBindings"]?[key] is JsonArray b && b.Count > 0) return b;
        throw new SetupException("Existing published bindings are missing; supply explicit TABLIX_BIND_IP and host ports.");
    }
    private static JsonObject Resolve(Options options, List<JsonObject> snapshot, IReadOnlyDictionary<string, string> env)
    {
        var path = Path.Combine(options.Base, DeploymentFile); var cfg = ReadDeployment(options.Base, validate: false);
        if (!File.Exists(path))
        {
            string requested = env.GetValueOrDefault("TABLIX_CONTAINER_NAME", Text(cfg["ContainerName"]));
            var existing = snapshot.FirstOrDefault(c => Name(c) == requested);
            if (existing is not null && !Owned(existing, options.HostBase)) throw new SetupException("Requested container belongs to another deployment.");
            if (existing is null)
            {
                var candidates = snapshot.Where(c => Owned(c, options.HostBase)).ToList();
                if (candidates.Count > 1) throw new SetupException("Multiple owned containers found; select TABLIX_CONTAINER_NAME explicitly.");
                existing = candidates.FirstOrDefault();
            }
            if (existing is not null)
            {
                cfg["ContainerName"] = Name(existing); var ips = new HashSet<string>();
                foreach (var (port, key, variable) in new[] { (9100, "RestPort", "TABLIX_REST_PORT"), (9102, "McpPort", "TABLIX_MCP_PORT") })
                {
                    JsonArray bindings;
                    try { bindings = Published(existing, port); }
                    catch (SetupException) when (env.ContainsKey(variable) && env.ContainsKey("TABLIX_BIND_IP")) { bindings = new(); }
                    var ports = bindings.Select(b => Text(b?["HostPort"])).ToHashSet();
                    if (ports.Count != 1 && !env.ContainsKey(variable)) throw new SetupException("Ambiguous published ports; supply explicit host ports.");
                    if (ports.Count == 1) cfg[key] = ports.Single();
                    foreach (var b in bindings) ips.Add(Text(b?["HostIp"]));
                }
                if (!env.ContainsKey("TABLIX_BIND_IP"))
                {
                    if (ips.Count != 1 || !IPAddress.TryParse(ips.Single(), out var ip) || ip.Equals(IPAddress.Any) || ip.Equals(IPAddress.IPv6Any))
                        throw new SetupException("Ambiguous or wildcard bindings; supply TABLIX_BIND_IP explicitly.");
                    cfg["BindIp"] = ips.Single();
                }
            }
        }
        foreach (var (key, variable) in new[] { ("ContainerName", "TABLIX_CONTAINER_NAME"), ("BindIp", "TABLIX_BIND_IP"), ("RestPort", "TABLIX_REST_PORT"), ("McpPort", "TABLIX_MCP_PORT"), ("Image", "TABLIX_IMAGE") })
            if (env.TryGetValue(variable, out string? value)) cfg[key] = value;
        if (env.TryGetValue("TABLIX_CONNECTION_FILE", out string? connection)) cfg["ConnectionFiles"] = new JsonArray(connection);
        ValidateDeployment(cfg);
        if (!options.Stop) StateAvailable(snapshot, options.HostBase, Text(cfg["ContainerName"]));
        var target = snapshot.FirstOrDefault(c => Name(c) == Text(cfg["ContainerName"]));
        if (target is not null && !Owned(target, options.HostBase)) throw new SetupException("Requested container belongs to another deployment; no settings were saved.");
        if (!File.Exists(path) || !JsonNode.DeepEquals(ReadObject(path), cfg)) SavePrivate(path, cfg); else Restrict(path);
        return cfg;
    }
    private static void Fields(JsonObject cfg, TextWriter output)
    {
        foreach (string key in new[] { "ContainerName", "BindIp", "RestPort", "McpPort", "Image" }) output.WriteLine(cfg[key]!.ToString());
    }
    private static void Guard(Options options, List<JsonObject> snapshot, TextWriter output)
    {
        string desired = Text(ReadDeployment(options.Base)["ContainerName"]);
        var existing = snapshot.FirstOrDefault(c => Name(c) == desired);
        if (options.Stop)
        {
            var running = snapshot.Where(c => Owned(c, options.HostBase) && Running(c)).ToList();
            if (running.Count > 1) throw new SetupException("Multiple owned containers are running; stop their actual Docker names explicitly.");
            if (running.Count == 1) existing = running[0];
        }
        else StateAvailable(snapshot, options.HostBase, desired);
        if (existing is not null && !Owned(existing, options.HostBase)) throw new SetupException("Refusing to stop or remove another deployment's container.");
        output.WriteLine(existing is null ? desired : Name(existing)); output.WriteLine(existing is null ? "absent" : Running(existing) ? "running" : "stopped");
    }
    private static void InitializeFile(string root, TextWriter output)
    {
        DirectoryPrivate(Path.Combine(root, "data")); DirectoryPrivate(Path.Combine(root, "logs"));
        var path = Path.Combine(root, "data", "tablix.db");
        if (!File.Exists(path)) using (CreatePrivate(path)) { }
        Restrict(path); output.WriteLine(new FileInfo(path).Length == 0 ? "1" : "0");
    }
    private static void PrepareState(string root)
    {
        PrepareStateFile(Path.Combine(root, "data", "tablix.db"));
    }
    private static void PrepareStateFile(string path)
    {
        if (!File.Exists(path)) throw new SetupException("Missing initialized data/tablix.db.");
        using var db = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = path, Mode = SqliteOpenMode.ReadWrite, Pooling = false, DefaultTimeout = 10 }.ToString()); db.Open();
        using var transaction = db.BeginTransaction();
        using var cmd = db.CreateCommand(); cmd.Transaction = transaction;
        foreach (var (table, columns) in new[] { ("model_providers", new[] { "id", "enabled", "health_check_enabled" }), ("database_connections", new[] { "id" }), ("database_allowed_queries", new[] { "database_id", "query_operation" }) })
        {
            cmd.CommandText = "PRAGMA table_info(" + table + ")"; var found = new HashSet<string>();
            using (var reader = cmd.ExecuteReader()) while (reader.Read()) found.Add(reader.GetString(1));
            if (columns.Any(c => !found.Contains(c))) throw new SetupException("Unexpected SQLite schema; refusing a networked start.");
        }
        cmd.CommandText = "SELECT COUNT(*) FROM model_providers";
        if (Convert.ToInt64(cmd.ExecuteScalar(), CultureInfo.InvariantCulture) == 0) throw new SetupException("Empty provider table would seed enabled defaults; restore a disabled provider record.");
        cmd.CommandText = "UPDATE model_providers SET enabled=0, health_check_enabled=0; DELETE FROM database_allowed_queries WHERE database_id='db_sample_sqlite' AND query_operation <> 'SELECT';"; cmd.ExecuteNonQuery();
        cmd.CommandText = "PRAGMA quick_check";
        using (var reader = cmd.ExecuteReader()) { if (!reader.Read() || reader.GetString(0) != "ok" || reader.Read()) throw new SetupException("SQLite integrity check failed."); }
        transaction.Commit(); Restrict(path);
    }

    private static async Task Register(Options options, TextWriter error)
    {
        var deployment = ReadDeployment(options.Base); var files = deployment["ConnectionFiles"]!.AsArray();
        if (files.Count == 0) return;
        var settings = PrepareConfig(options.Base); var entries = new List<JsonObject>();
        foreach (var filename in files)
        {
            string path = Text(filename);
            if (path.StartsWith(options.HostBase + "/", StringComparison.Ordinal)) path = Path.Combine(options.Base, path[(options.HostBase.Length + 1)..]);
            else if (!Path.IsPathRooted(path)) path = Path.Combine(options.Base, path);
            else throw new SetupException("Connection files must be inside the host package directory; use a relative path or its absolute host path.");
            path = Path.GetFullPath(path); string relative = Path.GetRelativePath(options.Base, path);
            if (relative == ".." || relative.StartsWith(".." + Path.DirectorySeparatorChar, StringComparison.Ordinal) || Path.IsPathRooted(relative))
                throw new SetupException("Connection files must remain inside the package directory.");
            if (!File.Exists(path)) throw new SetupException("Configured connection file is missing; place it inside the package directory.");
            Restrict(path); var entry = ReadObject(path); string id = Text(entry["Id"]);
            if (string.IsNullOrWhiteSpace(id) || id is "." or ".." || id.Any(char.IsControl))
                throw new SetupException("Each connection requires an explicit stable Id; no random ID is generated.");
            entries.Add(entry);
        }
        if (!Uri.TryCreate(options.Url, UriKind.Absolute, out var baseUri) || baseUri.Scheme != "http" || !baseUri.IsLoopback
            || baseUri.UserInfo.Length != 0 || baseUri.AbsolutePath != "/" || baseUri.Query.Length != 0 || baseUri.Fragment.Length != 0)
            throw new SetupException("Registration requires the service's internal loopback HTTP URL.");
        using var handler = new HttpClientHandler { AllowAutoRedirect = false, UseProxy = false };
        using var client = new HttpClient(handler) { BaseAddress = baseUri, Timeout = TimeSpan.FromSeconds(3) };
        client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", Text(settings["ApiKeys"]![0]));
        using (var ready = new CancellationTokenSource(TimeSpan.FromSeconds(options.Timeout)))
        {
            while (true)
            {
                int status = 0;
                try { (status, _) = await Request(client, HttpMethod.Get, "/", null, ready.Token); }
                catch (Exception ex) when (ex is HttpRequestException or OperationCanceledException or JsonException or SetupException)
                { if (ready.IsCancellationRequested) throw new SetupException("REST readiness timed out; verify credentials and container readiness."); }
                if (status == 200) break;
                if (status is 401 or 403) throw new SetupException("REST readiness failed; verify credentials and container readiness.");
                if (ready.IsCancellationRequested) throw new SetupException("REST readiness timed out; verify credentials and container readiness.");
                try { await Task.Delay(200, ready.Token); } catch (OperationCanceledException) { throw new SetupException("REST readiness timed out; verify credentials and container readiness."); }
            }
        }
        foreach (var entry in entries)
        {
            string id = Text(entry["Id"]), target = "/v1/database/" + Uri.EscapeDataString(id);
            using var phase = new CancellationTokenSource(TimeSpan.FromSeconds(options.Timeout));
            var (status, current) = await Request(client, HttpMethod.Get, target, null, phase.Token);
            if (status == 200)
            {
                ConfirmId(current, id); await error.WriteLineAsync("Connection already exists; configuration and context retained."); continue;
            }
            if (status != 404) throw new SetupException("Database lookup failed; no create or update attempted.");
            (status, _) = await Request(client, HttpMethod.Post, "/v1/database", entry, phase.Token);
            if (status == 409)
            {
                (status, current) = await Request(client, HttpMethod.Get, target, null, phase.Token);
                if (status != 200) throw new SetupException("Create conflicted but stable ID could not be confirmed.");
                ConfirmId(current, id); await error.WriteLineAsync("Connection created concurrently; retained without update."); continue;
            }
            if (status != 201) throw new SetupException("Database registration failed; connection details were not logged.");
            while (true)
            {
                (status, current) = await Request(client, HttpMethod.Get, target, null, phase.Token);
                if (status != 200) throw new SetupException("Database registered but crawl state could not be read.");
                ConfirmId(current, id);
                if (current["IsCrawled"] is JsonValue crawled && crawled.TryGetValue<bool>(out bool success) && success
                    && (current["CrawlError"] is null || current["CrawlError"]!.ToString().Length == 0)) break;
                await Task.Delay(200, phase.Token);
            }
            (status, var result) = await Request(client, HttpMethod.Post, target + "/query", new JsonObject { ["Query"] = "SELECT 1 AS ok" }, phase.Token);
            if (status != 200 || result["Success"]?.GetValue<bool>() != true || result["RowsReturned"]?.GetValue<int>() != 1
                || result["Data"]?["Rows"] is not JsonArray rows || rows.Count != 1 || rows[0]?["ok"]?.GetValue<decimal>() != 1)
                throw new SetupException("Database registered but SELECT 1 verification failed; connection details were not logged.");
            await error.WriteLineAsync("Connection registered and verified.");
        }
    }
    private static void ConfirmId(JsonObject current, string id)
    {
        if ((current["DatabaseId"] ?? current["Id"])?.ToString() != id)
            throw new SetupException("REST returned an unexpected database ID; no update was made.");
    }
    private static async Task<(int Status, JsonObject Body)> Request(HttpClient client, HttpMethod method, string path, JsonObject? body, CancellationToken token)
    {
        using var request = new HttpRequestMessage(method, path);
        if (body is not null) request.Content = new StringContent(body.ToJsonString(), System.Text.Encoding.UTF8, "application/json");
        using var response = await client.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, token);
        int status = (int)response.StatusCode;
        if (status is < 200 or >= 300) return (status, new());
        var text = await response.Content.ReadAsStringAsync(token);
        if (text.Length == 0) return (status, new());
        if (JsonNode.Parse(text) is not JsonObject value) throw new SetupException("REST returned invalid JSON; bootstrap stopped.");
        return (status, value);
    }
}
