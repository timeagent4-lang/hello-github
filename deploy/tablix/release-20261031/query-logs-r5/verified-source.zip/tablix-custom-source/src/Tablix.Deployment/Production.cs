using System.Globalization;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using Tablix.Core.Enums;
using Tablix.Core.Helpers;
using Tablix.Core.Persistence;
using Tablix.Core.Settings;

namespace Tablix.Deployment;

public static partial class Program
{
    private static string ProductionId(IReadOnlyDictionary<string, string> env)
    {
        string id = env.GetValueOrDefault("MYSQL_ID", "db_internal_mysql");
        if (!Regex.IsMatch(id, @"\A[A-Za-z0-9][A-Za-z0-9_.-]{0,127}\z") || id == "db_sample_sqlite")
            throw new SetupException("MYSQL_ID must be a stable ASCII identifier, not the sample database ID.");
        return id;
    }
    private static string RequiredProductionValue(IReadOnlyDictionary<string, string> env, string key)
    {
        string value = env.GetValueOrDefault(key, "");
        if (string.IsNullOrWhiteSpace(value) || value.StartsWith("REPLACE_", StringComparison.OrdinalIgnoreCase))
            throw new SetupException("Fill " + key + " in .env before starting; no state was prepared.");
        return value;
    }
    private static async Task PrepareProduction(Options options, IReadOnlyDictionary<string, string> env, TextWriter error)
    {
        // Validate all user input before creating or migrating any persisted state.
        string id = ProductionId(env), host = RequiredProductionValue(env, "MYSQL_HOST"), user = RequiredProductionValue(env, "MYSQL_USER");
        string password = RequiredProductionValue(env, "MYSQL_PASSWORD"), database = RequiredProductionValue(env, "MYSQL_DATABASE");
        if (!int.TryParse(env.GetValueOrDefault("MYSQL_PORT", "3306"), NumberStyles.None, CultureInfo.InvariantCulture, out int port) || port < 1 || port > 65535)
            throw new SetupException("MYSQL_PORT must be an integer from 1 to 65535.");
        string schema = env.GetValueOrDefault("MYSQL_SCHEMA", ""); if (string.IsNullOrWhiteSpace(schema)) schema = database;
        var policy = new McpSettings
        {
            ToolNamePrefix = env.GetValueOrDefault("TABLIX_TOOL_PREFIX", "tablix_"),
            DisabledTools = env.TryGetValue("TABLIX_DISABLED_TOOLS", out var disabled)
                ? disabled.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).ToList()
                : DisabledTools.ToList()
        };
        try { _ = new McpToolPolicy(policy); } catch (ArgumentException) { throw new SetupException("Invalid TABLIX_TOOL_PREFIX or TABLIX_DISABLED_TOOLS."); }
        string key = env.GetValueOrDefault("TABLIX_REST_API_KEY", "");
        if (key.Length != 0 && (key.Length < 32 || key.Any(char.IsControl) || key.StartsWith("REPLACE_", StringComparison.OrdinalIgnoreCase)))
            throw new SetupException("TABLIX_REST_API_KEY must be empty for persisted automatic generation, or at least 32 characters.");
        string cfgPath = Path.Combine(options.Base, "tablix.json");
        if (key.Length == 0 && File.Exists(cfgPath))
        {
            var old = ReadObject(cfgPath);
            key = old["ApiKeys"]?[0]?.GetValue<string>() ?? "";
            if (key.Length < 32 || key.Any(char.IsControl)) throw new SetupException("Saved REST API key is invalid; supply TABLIX_REST_API_KEY explicitly.");
        }
        if (key.Length == 0) key = Convert.ToHexString(RandomNumberGenerator.GetBytes(32)).ToLowerInvariant();
        string logDirectory = env.GetValueOrDefault("TABLIX_LOG_DIRECTORY", "/app/logs");
        if (!Path.IsPathFullyQualified(logDirectory)) throw new SetupException("TABLIX_LOG_DIRECTORY must be absolute.");
        string dbPath = Path.Combine(options.Base, "tablix.db");
        var cfg = new JsonObject
        {
            ["Persistence"] = new JsonObject { ["Type"] = "Sqlite", ["Filename"] = dbPath },
            ["Rest"] = new JsonObject { ["Hostname"] = "127.0.0.1", ["McpHostname"] = "*", ["Port"] = 9100, ["McpPort"] = 9102, ["Ssl"] = false },
            ["ApiKeys"] = new JsonArray(key),
            ["Mcp"] = new JsonObject { ["ToolNamePrefix"] = policy.ToolNamePrefix, ["DisabledTools"] = new JsonArray(policy.DisabledTools.Select(x => (JsonNode?)JsonValue.Create(x)).ToArray()) },
            ["Chat"] = new JsonObject { ["Enabled"] = false },
            ["Telemetry"] = new JsonObject { ["Enable"] = false, ["OtlpEnable"] = false, ["PrometheusEnable"] = false, ["LokiEnable"] = false, ["ExportLogs"] = false, ["TraceSamplingRatio"] = 0 },
            ["Logging"] = new JsonObject { ["Servers"] = new JsonArray(), ["ConsoleLogging"] = true, ["FileLogging"] = true, ["LogDirectory"] = logDirectory.TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar, ["LogFilename"] = "tablix.log", ["MinimumSeverity"] = 1, ["EnableColors"] = false }
        };
        DirectoryPrivate(options.Base); DirectoryPrivate(logDirectory);
        bool fresh = !File.Exists(dbPath) || new FileInfo(dbPath).Length == 0;
        // Factory initialization only creates/migrates SQLite and seeds records; it starts no network workers.
        await using (var driver = await DatabaseDriverFactory.CreateAndInitializeAsync(new PersistenceDatabaseSettings { Filename = dbPath }))
        {
            var existing = await driver.DatabaseConnections.ReadAsync(id);
            var entry = existing ?? new DatabaseEntry { Id = id };
            entry.Name = env.GetValueOrDefault("MYSQL_NAME", "Internal MySQL"); entry.Type = DatabaseTypeEnum.Mysql;
            entry.Hostname = host; entry.Port = port; entry.DatabaseName = database; entry.Schema = schema;
            entry.User = user; entry.Password = password; entry.Filename = null; entry.AllowedQueries = ["SELECT"];
            // Only connection fields belong to .env. Existing curated Context remains authoritative.
            if (existing is null) await driver.DatabaseConnections.CreateAsync(entry);
            else
            {
                // A null Context skips the driver's context upsert, preserving text, source and timestamps.
                entry.Context = null;
                await driver.DatabaseConnections.UpdateAsync(entry, false);
            }
            if (fresh) await driver.DatabaseConnections.DeleteAsync("db_sample_sqlite");
        }
        PrepareStateFile(dbPath); // Must complete before the application can start any provider health worker.
        SavePrivate(cfgPath, cfg);
        await error.WriteLineAsync("Production state prepared; MySQL connection synchronized; existing Context retained; models and telemetry disabled.");
    }
    private static async Task VerifyProduction(Options options, IReadOnlyDictionary<string, string> env, TextWriter error)
    {
        string id = ProductionId(env);
        if (!Uri.TryCreate(options.Url, UriKind.Absolute, out var uri) || uri.Scheme != "http" || !uri.IsLoopback
            || uri.UserInfo.Length != 0 || uri.AbsolutePath != "/" || uri.Query.Length != 0 || uri.Fragment.Length != 0)
            throw new SetupException("Production verification requires the service's loopback HTTP URL.");
        var cfg = ReadObject(Path.Combine(options.Base, "tablix.json"));
        using var client = new HttpClient(new HttpClientHandler { AllowAutoRedirect = false, UseProxy = false }) { BaseAddress = uri, Timeout = System.Threading.Timeout.InfiniteTimeSpan };
        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Text(cfg["ApiKeys"]![0]));
        using var deadline = new CancellationTokenSource(TimeSpan.FromSeconds(options.Timeout));
        string target = "/v1/database/" + Uri.EscapeDataString(id);
        while (true)
        {
            try
            {
                var (status, _) = await Request(client, HttpMethod.Get, "/", null, deadline.Token);
                if (status is 401 or 403) throw new SetupException("Production verification authentication failed.");
                if (status == 200) break;
            }
            catch (HttpRequestException) { }
            catch (OperationCanceledException) when (!deadline.IsCancellationRequested) { }
            if (deadline.IsCancellationRequested) throw new SetupException("MySQL crawl readiness timed out; check local connection settings and service logs.");
            try { await Task.Delay(200, deadline.Token); } catch (OperationCanceledException) { throw new SetupException("MySQL crawl readiness timed out; check local connection settings and service logs."); }
        }
        // GET database detail can prefer old persisted metadata. This synchronous POST forces a new crawl
        // and persists its result; only that response may satisfy current-startup schema readiness.
        var (crawlStatus, detail) = await Request(client, HttpMethod.Post, target + "/crawl", null, deadline.Token);
        if (crawlStatus != 200) throw new SetupException("Fresh MySQL schema crawl request failed; response details were not logged.");
        ConfirmId(detail, id);
        if (detail["IsCrawled"]?.GetValue<bool>() != true || !string.IsNullOrEmpty(detail["CrawlError"]?.ToString()))
            throw new SetupException("Fresh MySQL schema crawl failed; response details were not logged.");
        var (queryStatus, result) = await Request(client, HttpMethod.Post, target + "/query", new JsonObject { ["Query"] = "SELECT 1 AS ok" }, deadline.Token);
        if (queryStatus != 200 || result["Success"]?.GetValue<bool>() != true || result["RowsReturned"]?.GetValue<int>() != 1
            || result["Data"]?["Rows"] is not JsonArray rows || rows.Count != 1 || rows[0]?["ok"]?.GetValue<decimal>() != 1)
            throw new SetupException("MySQL SELECT 1 verification failed; connection and server response details were not logged.");
        await error.WriteLineAsync("MySQL crawl and SELECT 1 verified; production service is ready.");
    }
}
