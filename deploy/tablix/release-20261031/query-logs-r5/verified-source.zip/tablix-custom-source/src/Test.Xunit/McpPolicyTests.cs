namespace Test.Xunit
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Net.Sockets;
    using System.Text;
    using System.Text.Json;
    using System.Text.Json.Nodes;
    using System.Threading;
    using System.Threading.Tasks;
    using Microsoft.Data.Sqlite;
    using Tablix.Core.Helpers;
    using Tablix.Core.Persistence.Sqlite;
    using Tablix.Core.Settings;
    using Tablix.Server;
    using Tablix.Server.Mcp;
    using Test.Shared;
    using global::Xunit;

    /// <summary>
    /// MCP policy contracts at the real registration, settings, and HTTP boundaries.
    /// </summary>
    public sealed class McpPolicyTests
    {
        /// <summary>
        /// Catch a registrar that keeps context writers reachable under the default policy.
        /// </summary>
        [Fact]
        public async Task DefaultRegistrationOmitsAllThreeContextWriters()
        {
            string directory = CreateDirectory();
            try
            {
                await using SqliteDatabaseDriver persistence = new SqliteDatabaseDriver(Path.Combine(directory, "tablix.db"));
                await persistence.InitializeAsync(CancellationToken.None);
                Dictionary<string, Func<object, Task<object>>> handlers = new Dictionary<string, Func<object, Task<object>>>();
                McpToolRegistrar.RegisterAll((name, description, schema, handler) => handlers.Add(name, handler), persistence, new CrawlCache());

                Assert.Equal(new[]
                {
                    "tablix_discover_database", "tablix_discover_databases", "tablix_discover_table", "tablix_execute_query",
                    "tablix_get_agent_pack", "tablix_get_database_context", "tablix_get_database_intelligence",
                    "tablix_get_table_context", "tablix_list_relationships", "tablix_list_tables"
                }, handlers.Keys.OrderBy(name => name, StringComparer.Ordinal));
            }
            finally { Directory.Delete(directory, true); }
        }

        /// <summary>
        /// Catch debug names that retain an obsolete prefix or follow settings mutations before restart.
        /// </summary>
        [Fact]
        public async Task DebugNamesUseTheRegisteredStartupPrefix()
        {
            string directory = CreateDirectory();
            try
            {
                await using SqliteDatabaseDriver persistence = new SqliteDatabaseDriver(Path.Combine(directory, "tablix.db"));
                await persistence.InitializeAsync(CancellationToken.None);
                Dictionary<string, Func<object, Task<object>>> handlers = new Dictionary<string, Func<object, Task<object>>>();
                List<string> messages = new List<string>();
                McpSettings policy = new McpSettings { ToolNamePrefix = "startup_" };
                McpToolRegistrar.RegisterAll((name, description, schema, handler) => handlers.Add(name, handler), persistence, new CrawlCache(), messages.Add, policy);
                policy.ToolNamePrefix = "later_";
                policy.DisabledTools.Add("discover_database");

                await handlers["startup_discover_database"](new { databaseId = "missing_debug_database" });

                Assert.Equal(new[] { "[MCP] startup_discover_database invoked" }, messages);
            }
            finally { Directory.Delete(directory, true); }
        }

        /// <summary>
        /// Catch writer handlers that remain callable despite being absent from discovery.
        /// </summary>
        [Fact]
        public async Task DefaultHttpPolicyRejectsContextWritesAndKeepsAdminRestContextMaintenance()
        {
            await WithServerAsync("{}", async live =>
            {
                using JsonDocument listing = await SendAsync(live.Session, "tools/list", new { });
                Assert.Equal(10, listing.RootElement.GetProperty("result").GetProperty("tools").GetArrayLength());
                using HttpClient client = new HttpClient();
                client.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", "Bearer tablixadmin");
                using HttpResponseMessage created = await client.PostAsync(live.RestUrl + "/v1/database", new StringContent(
                    JsonSerializer.Serialize(new { Id = "protected_db", Name = "Context policy test", Type = "Sqlite", Filename = live.DatabaseFile, Context = "Human approved context" }), Encoding.UTF8, "application/json"));
                Assert.True(created.IsSuccessStatusCode, await created.Content.ReadAsStringAsync());

                foreach (string name in new[] { "tablix_update_context", "tablix_update_database_context", "tablix_update_table_context" })
                {
                    using JsonDocument rejected = await SendAsync(live.Session, "tools/call", new { name, arguments = new { databaseId = "protected_db", tableId = "protected_table", context = "Unwanted MCP replacement", mode = "replace" } });
                    Assert.True(IsError(rejected.RootElement), name + " must be unregistered.");
                }
                using JsonDocument unchanged = JsonDocument.Parse(await client.GetStringAsync(live.RestUrl + "/v1/database/protected_db"));
                Assert.Equal("Human approved context", unchanged.RootElement.GetProperty("Context").GetString());
                using HttpResponseMessage maintained = await client.PostAsync(live.RestUrl + "/v1/database/protected_db/context", new StringContent("{\"Context\":\"Updated by admin REST\",\"Mode\":\"replace\"}", Encoding.UTF8, "application/json"));
                Assert.True(maintained.IsSuccessStatusCode, await maintained.Content.ReadAsStringAsync());
                using JsonDocument changed = JsonDocument.Parse(await client.GetStringAsync(live.RestUrl + "/v1/database/protected_db"));
                Assert.Equal("Updated by admin REST", changed.RootElement.GetProperty("Context").GetString());
            });
        }

        /// <summary>
        /// Catch ignored file settings, hidden-only filtering, or obsolete aliases.
        /// </summary>
        [Fact]
        public async Task CustomPrefixAndDisabledToolsControlHttpRegistrationAndInvocation()
        {
            await WithServerAsync("{\"ToolNamePrefix\":\"team_\",\"DisabledTools\":[\"execute_query\",\"discover_database\"]}", async live =>
            {
                using JsonDocument listing = await SendAsync(live.Session, "tools/list", new { });
                string[] names = listing.RootElement.GetProperty("result").GetProperty("tools").EnumerateArray()
                    .Select(tool => tool.GetProperty("name").GetString()).OrderBy(name => name, StringComparer.Ordinal).ToArray();
                Assert.Equal(new[]
                {
                    "team_discover_databases", "team_discover_table", "team_get_agent_pack", "team_get_database_context",
                    "team_get_database_intelligence", "team_get_table_context", "team_list_relationships", "team_list_tables",
                    "team_update_context", "team_update_database_context", "team_update_table_context"
                }, names);

                using JsonDocument enabled = await SendAsync(live.Session, "tools/call", new { name = "team_get_database_context", arguments = new { databaseId = "policy_missing_database" } });
                Assert.Contains("policy_missing_database", enabled.RootElement.GetRawText());
                foreach (string name in new[] { "team_execute_query", "team_discover_database", "tablix_get_database_context", "tablix_execute_query" })
                {
                    using JsonDocument rejected = await SendAsync(live.Session, "tools/call", new { name, arguments = new { databaseId = "policy_missing_database" } });
                    Assert.True(IsError(rejected.RootElement), name + " must have no callable handler: " + rejected.RootElement.GetRawText());
                    Assert.DoesNotContain("policy_missing_database", rejected.RootElement.GetRawText());
                }
            });
        }

        /// <summary>
        /// Catch stale tool recommendations after renaming or disabling dependencies.
        /// </summary>
        [Fact]
        public async Task DescriptionsAndAgentPackUseOnlyAvailableConfiguredToolNames()
        {
            await WithServerAsync("{\"ToolNamePrefix\":\"team_\",\"DisabledTools\":[\"list_tables\",\"update_context\",\"update_database_context\",\"update_table_context\"]}", async live =>
            {
                using JsonDocument listing = await SendAsync(live.Session, "tools/list", new { });
                string guidance = String.Join(" ", listing.RootElement.GetProperty("result").GetProperty("tools").EnumerateArray().Select(tool => tool.GetProperty("description").GetString()));
                Assert.DoesNotContain("tablix_", guidance);
                Assert.DoesNotContain("tablix_", listing.RootElement.GetRawText());
                Assert.DoesNotContain("team_list_tables", guidance);
                Assert.DoesNotContain("team_update_", guidance);
                Assert.Contains("team_discover_table", guidance);

                using HttpClient client = new HttpClient();
                using HttpRequestMessage create = new HttpRequestMessage(HttpMethod.Post, live.RestUrl + "/v1/database");
                create.Headers.TryAddWithoutValidation("Authorization", "Bearer tablixadmin");
                create.Content = new StringContent("{\"Id\":\"policy_db\",\"Name\":\"Policy test\",\"Type\":\"Sqlite\",\"Filename\":\"" + live.DatabaseFile.Replace("\\", "\\\\") + "\"}", Encoding.UTF8, "application/json");
                using HttpResponseMessage created = await client.SendAsync(create);
                Assert.True(created.IsSuccessStatusCode, await created.Content.ReadAsStringAsync());

                foreach (string name in new[] { "team_get_agent_pack", "team_get_database_intelligence" })
                {
                    using JsonDocument response = await SendAsync(live.Session, "tools/call", new { name, arguments = new { databaseId = "policy_db" } });
                    string pack = response.RootElement.GetRawText();
                    Assert.Contains("team_discover_databases", pack);
                    Assert.DoesNotContain("tablix_", pack);
                    Assert.DoesNotContain("team_list_tables", pack);
                }
                using HttpRequestMessage restPack = new HttpRequestMessage(HttpMethod.Get, live.RestUrl + "/v1/database/policy_db/agent-pack");
                restPack.Headers.TryAddWithoutValidation("Authorization", "Bearer tablixadmin");
                using HttpResponseMessage restResponse = await client.SendAsync(restPack);
                Assert.True(restResponse.IsSuccessStatusCode, await restResponse.Content.ReadAsStringAsync());
                string restGuidance = await restResponse.Content.ReadAsStringAsync();
                Assert.Contains("team_discover_databases", restGuidance);
                Assert.DoesNotContain("tablix_", restGuidance);
                Assert.DoesNotContain("team_list_tables", restGuidance);
            });
        }

        /// <summary>
        /// Catch a REST update that reconstructs root settings and resets the MCP policy.
        /// </summary>
        [Fact]
        public async Task UnrelatedRestSettingsUpdatePreservesMcpPolicyOnDisk()
        {
            await WithServerAsync("{\"ToolNamePrefix\":\"saved_\",\"DisabledTools\":[\"execute_query\"]}", async live =>
            {
                using HttpClient client = new HttpClient();
                using HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Put, live.RestUrl + "/v1/settings");
                request.Headers.TryAddWithoutValidation("Authorization", "Bearer tablixadmin");
                request.Content = new StringContent("{\"ApiKeys\":[\"tablixadmin\",\"new-policy-key\"]}", Encoding.UTF8, "application/json");
                using HttpResponseMessage response = await client.SendAsync(request);
                Assert.True(response.IsSuccessStatusCode, await response.Content.ReadAsStringAsync());
                using JsonDocument saved = JsonDocument.Parse(File.ReadAllText(live.SettingsFile));
                Assert.True(saved.RootElement.TryGetProperty("Mcp", out JsonElement mcp), "REST settings writes must retain Mcp.");
                Assert.Equal("saved_", mcp.GetProperty("ToolNamePrefix").GetString());
                Assert.Equal(new[] { "execute_query" }, mcp.GetProperty("DisabledTools").EnumerateArray().Select(item => item.GetString()));
            });
        }

        /// <summary>
        /// Catch permissive validation that silently exposes an intended disabled tool.
        /// </summary>
        /// <param name="mcpJson">Invalid MCP policy.</param>
        /// <param name="field">Setting that must be identified in the startup failure.</param>
        [Theory]
        [InlineData("{\"DisabledTools\":[\"execute_qurey\"]}", "Mcp.DisabledTools")]
        [InlineData("{\"DisabledTools\":[\"tablix_execute_query\"]}", "Mcp.DisabledTools")]
        [InlineData("{\"DisabledTools\":[null]}", "Mcp.DisabledTools")]
        [InlineData("{\"DisabledTools\":null}", "Mcp.DisabledTools")]
        [InlineData("null", "Mcp")]
        [InlineData("{\"ToolNamePrefix\":\"bad prefix_\"}", "Mcp.ToolNamePrefix")]
        [InlineData("{\"ToolNamePrefix\":null}", "Mcp.ToolNamePrefix")]
        public void InvalidPolicyFailsSettingsLoadClearly(string mcpJson, string field)
        {
            string directory = CreateDirectory();
            try
            {
                string filename = WriteSettings(directory, mcpJson);
                Exception failure = Assert.ThrowsAny<ArgumentException>(() => new SettingsManager(filename));
                Assert.Contains(field, failure.Message);
            }
            finally { Directory.Delete(directory, true); }
        }

        /// <summary>
        /// Catch off-by-one validation of the longest registered MCP name.
        /// </summary>
        [Fact]
        public void PrefixValidationAllows64CharacterToolNamesAndRejects65()
        {
            string directory = CreateDirectory();
            try
            {
                string filename = WriteSettings(directory, "{\"ToolNamePrefix\":\"" + new string('a', 39) + "\"}");
                Assert.NotNull(new SettingsManager(filename));
                WriteSettings(directory, "{\"ToolNamePrefix\":\"" + new string('a', 40) + "\"}");
                ArgumentException failure = Assert.ThrowsAny<ArgumentException>(() => new SettingsManager(filename));
                Assert.Contains("64", failure.Message);
            }
            finally { Directory.Delete(directory, true); }
        }

        private static async Task WithServerAsync(string mcpJson, Func<LiveServer, Task> action)
        {
            string directory = CreateDirectory();
            string settingsFile = WriteSettings(directory, mcpJson);
            TablixSettings settings = Serializer.DeserializeJson<TablixSettings>(File.ReadAllText(settingsFile));
            TablixServer server = new TablixServer(settingsFile);
            using CancellationTokenSource timeout = new CancellationTokenSource(TimeSpan.FromSeconds(60));
            try
            {
                await server.StartAsync(timeout.Token);
                McpTestSession session = await McpTestSession.OpenAsync("http://127.0.0.1:" + settings.Rest.McpPort + "/mcp", timeout.Token);
                await action(new LiveServer { Session = session, SettingsFile = settingsFile, DatabaseFile = Path.Combine(directory, "tablix.db"), RestUrl = "http://127.0.0.1:" + settings.Rest.Port });
            }
            finally
            {
                timeout.Cancel();
                await server.StopAsync();
                // SqliteCrawler pools its read connections; release only this fixture's pool before deleting it.
                using SqliteConnection fixtureConnection = new SqliteConnection("Data Source=" + Path.Combine(directory, "tablix.db"));
                SqliteConnection.ClearPool(fixtureConnection);
                Directory.Delete(directory, true);
            }
        }

        private static string WriteSettings(string directory, string mcpJson)
        {
            TablixSettings settings = new TablixSettings();
            settings.Rest.Hostname = "127.0.0.1";
            settings.Rest.Port = GetPort();
            settings.Rest.McpPort = GetPort();
            settings.Persistence.Filename = "tablix.db";
            settings.Logging.ConsoleLogging = false;
            settings.Logging.FileLogging = false;
            JsonObject root = JsonNode.Parse(Serializer.SerializeJson(settings)).AsObject();
            root["Mcp"] = JsonNode.Parse(mcpJson);
            string filename = Path.Combine(directory, "tablix.json");
            File.WriteAllText(filename, root.ToJsonString());
            return filename;
        }

        private static int GetPort()
        {
            TcpListener listener = new TcpListener(IPAddress.Loopback, 0);
            listener.Start();
            int port = ((IPEndPoint)listener.LocalEndpoint).Port;
            listener.Stop();
            return port;
        }

        private static string CreateDirectory()
        {
            string directory = Path.Combine(Path.GetTempPath(), "tablix_policy_" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(directory);
            return directory;
        }

        private static async Task<JsonDocument> SendAsync(McpTestSession session, string method, object parameters)
        {
            string body = JsonSerializer.Serialize(new { jsonrpc = "2.0", id = 1, method, @params = parameters });
            string response = (await session.PostAsync(body, CancellationToken.None)).Trim();
            if (!response.StartsWith("{", StringComparison.Ordinal))
                response = response.Split('\n').Select(line => line.Trim()).Last(line => line.StartsWith("data:", StringComparison.Ordinal)).Substring(5).Trim();
            return JsonDocument.Parse(response);
        }

        private static bool IsError(JsonElement response)
        {
            return response.TryGetProperty("error", out _) ||
                (response.TryGetProperty("result", out JsonElement result) && result.TryGetProperty("isError", out JsonElement error) && error.ValueKind == JsonValueKind.True);
        }

        private sealed class LiveServer
        {
            public McpTestSession Session { get; set; }
            public string SettingsFile { get; set; }
            public string DatabaseFile { get; set; }
            public string RestUrl { get; set; }
        }
    }
}
