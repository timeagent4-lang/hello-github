namespace Test.Xunit
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using System.Text.Json;
    using Tablix.Core.Models;
    using Tablix.Server.Observability;
    using global::Xunit;

    public sealed class McpFailureDetailsTests
    {
        [Fact]
        public async Task FailureResultLogsTheSpecificErrorAndDatabaseWithoutChangingTheResponse()
        {
            var result = new QueryResult { Success = false, DatabaseId = "internal_mysql", Error = "Unknown column 'metric_code' in 'field list'; server=10.1.2.3; password=fixture-password" };
            var info = new List<string>(); var warnings = new List<string>();
            object response = await McpToolDiagnostics.InvokeAsync("tablix_execute_query", () => Task.FromResult<object>(result), info.Add, warnings.Add);
            Assert.Same(result, response);
            string text = string.Join("\n", warnings);
            Assert.Contains("metric_code", text); Assert.Contains("10.1.2.3", text); Assert.Contains("internal_mysql", text);
            Assert.Contains("[redacted]", text); Assert.DoesNotContain("fixture-password", text);
            Assert.Contains("status=failure_result", string.Join("\n", info));
        }

        [Fact]
        public void ExceptionDescriptionKeepsTheMessageButHidesConfiguredUnlabelledCredentials()
        {
            string text = McpToolDiagnostics.Describe(new InvalidOperationException("Cannot connect to mysql.internal; credential: fixture-secret; table=metric_data"), new[] { "fixture-secret" });
            Assert.Contains("Cannot connect", text); Assert.Contains("mysql.internal", text); Assert.Contains("metric_data", text);
            Assert.DoesNotContain("fixture-secret", text); Assert.Contains("[redacted]", text);
        }

        [Theory]
        [InlineData("Password=fixture-secret;Server=10.1.2.3")]
        [InlineData("Pwd='fixture-secret';Database=metrics")]
        [InlineData("password=\"fixture-secret\";User ID=readonly")]
        [InlineData("{\"password\":\"fixture-secret\",\"table\":\"metrics\"}")]
        [InlineData("API_KEY=fixture-secret")]
        [InlineData("api-key: fixture-secret")]
        [InlineData("{\"apiKey\":\"fixture-secret\"}")]
        [InlineData("access_token=fixture-secret&metric=123")]
        [InlineData("refreshToken: fixture-secret")]
        [InlineData("Authorization: Bearer fixture-secret")]
        [InlineData("Authorization: Basic fixture-secret")]
        [InlineData("{\"Authorization\":\"Bearer fixture-secret\"}")]
        [InlineData("https://readonly:fixture-secret@mysql.internal:3306/metrics")]
        [InlineData("mysql://readonly:fixture-secret@10.1.2.3/metrics")]
        [InlineData("https://internal/query?token=fixture-secret&table=metrics")]
        [InlineData("client_secret=fixture-secret")]
        public void CredentialFormatsAreRedactedWithoutAConfiguredValue(string message)
        {
            string text = McpToolDiagnostics.Describe(new InvalidOperationException(message));
            Assert.DoesNotContain("fixture-secret", text); Assert.Contains("[redacted]", text);
        }

        [Fact]
        public void SqlAndBusinessNamesRemainAvailableAndNewlinesCannotForgeLogEntries()
        {
            string text = McpToolDiagnostics.Describe(new InvalidOperationException("SELECT amount FROM metric_table WHERE code='M001'\nforged-entry"));
            Assert.Contains("SELECT amount FROM metric_table", text); Assert.Contains("M001", text);
            Assert.DoesNotContain("\n", text); Assert.DoesNotContain("\r", text);
        }

        [Fact]
        public async Task SuccessfulResultsDoNotLogReturnedRows()
        {
            var info = new List<string>(); var warnings = new List<string>();
            var result = new { Success = true, Data = "business-row-value" };
            Assert.Same(result, await McpToolDiagnostics.InvokeAsync("fixture", () => Task.FromResult<object>(result), info.Add, warnings.Add));
            Assert.Empty(warnings); Assert.DoesNotContain("business-row-value", string.Join("\n", info));
        }

        [Fact]
        public void RedactionIsIdempotentAndKeepsUsefulConnectionDetails()
        {
            const string source = "Server=mysql.internal;Database=metrics;User ID=readonly;Password=fixture-secret";
            string once = CredentialLogRedactor.Redact(source, new[] { "fixture-secret" });
            Assert.Equal(once, CredentialLogRedactor.Redact(once));
            Assert.Contains("Server=mysql.internal;Database=metrics;User ID=readonly", once);
            Assert.DoesNotContain("fixture-secret", once);
        }

        [Fact]
        public async Task DiagnosticCredentialLookupFailureCannotLeakOrChangeTheToolResponse()
        {
            var result = new QueryResult { Success = false, Error = "unlabelled-sensitive-value" };
            var warnings = new List<string>();
            object response = await McpToolDiagnostics.InvokeAsync("fixture", () => Task.FromResult<object>(result), _ => { }, warnings.Add,
                resolveSecrets: () => throw new InvalidOperationException("lookup failed"));
            Assert.Same(result, response);
            Assert.DoesNotContain("unlabelled-sensitive-value", string.Join("\n", warnings));
            Assert.Contains("credential lookup failed", string.Join("\n", warnings));
        }

        [Fact]
        public void JsonPathCannotBypassCredentialRedaction()
        {
            var error = new JsonException("integer expected", "$.fixture-secret", 1, 2);
            Assert.DoesNotContain("fixture-secret", McpToolDiagnostics.Describe(error, new[] { "fixture-secret" }));
            Assert.DoesNotContain("fixture-secret", McpToolDiagnostics.Describe(error, credentialsComplete: false));
        }

        [Theory]
        [InlineData("Password=\"foo\"\"bar\";Server=mysql.internal", "foo\"bar")]
        [InlineData("Password=\"foo'bar\"\"baz\";Server=mysql.internal", "foo'bar\"baz")]
        public void QuotedConnectionStringCredentialsAreFullyRedacted(string source, string password)
        {
            Assert.Equal("Password=[redacted];Server=mysql.internal", CredentialLogRedactor.Redact(source, new[] { password }));
            Assert.Equal("Password=[redacted];Server=mysql.internal", CredentialLogRedactor.Redact(source));
        }
    }
}
