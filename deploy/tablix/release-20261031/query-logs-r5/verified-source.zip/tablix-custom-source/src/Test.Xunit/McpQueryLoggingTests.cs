namespace Test.Xunit
{
    using System;
    using System.Collections.Generic;
    using System.Text.Json;
    using System.Threading.Tasks;
    using Tablix.Core.Models;
    using Tablix.Core.Settings;
    using Tablix.Server.Observability;
    using global::Xunit;

    public sealed class McpQueryLoggingTests
    {
        [Theory]
        [InlineData(0)]
        [InlineData(28)]
        public async Task QueryLogsSqlAndExactReturnedRowCount(int count)
        {
            var info = new List<string>();
            var result = new QueryResult { Success = true, DatabaseId = "internal_mysql", RowsReturned = count };
            object response = await McpToolDiagnostics.InvokeAsync("tablix_execute_query", () => Task.FromResult<object>(result), info.Add, _ => { },
                queryArguments: () => JsonSerializer.SerializeToElement(new { databaseId = "internal_mysql", query = "  SELECT metric_code FROM metric_daily;  " }),
                resolveDatabase: id => Task.FromResult(new DatabaseEntry { Id = id, DatabaseName = "business_metrics", Name = "生产指标库" }));
            Assert.Same(result, response);
            string text = string.Join("\n", info);
            Assert.Contains("databaseId=\"internal_mysql\"", text); Assert.Contains("sql=\"SELECT metric_code FROM metric_daily\"", text);
            Assert.Contains("status=success rowsReturned=" + count + " elapsedMs=", text);
            Assert.Contains("databaseName=\"business_metrics\"", text); Assert.Contains("databaseLabel=\"生产指标库\"", text);
        }

        [Fact]
        public async Task QueryCredentialsAreRedactedBeforeSuccessLogsAndResolvedOnlyOnce()
        {
            int lookups = 0; var info = new List<string>();
            await McpToolDiagnostics.InvokeAsync("custom_execute_query", () => Task.FromResult<object>(new QueryResult { RowsReturned = 1 }), info.Add, _ => { },
                resolveSecrets: () => { lookups++; return Task.FromResult<IEnumerable<string>>(new[] { "fixture-secret" }); },
                queryArguments: () => JsonSerializer.SerializeToElement(new { databaseId = "db", query = "SELECT 'fixture-secret' AS example, 123 AS business_value" }));
            Assert.Equal(1, lookups);
            string text = string.Join("\n", info);
            Assert.DoesNotContain("fixture-secret", text); Assert.Contains("[redacted]", text); Assert.Contains("123 AS business_value", text);
        }

        [Fact]
        public async Task FailedQueryLogsUnknownRowsAndTheExistingErrorWithoutDuplicateCredentialReads()
        {
            int lookups = 0; var logs = new List<string>();
            var result = new QueryResult { Success = false, Error = "Unknown column missing_metric", DatabaseId = "db" };
            Assert.Same(result, await McpToolDiagnostics.InvokeAsync("execute_query", () => Task.FromResult<object>(result), logs.Add, logs.Add,
                resolveSecrets: () => { lookups++; return Task.FromResult<IEnumerable<string>>(Array.Empty<string>()); },
                queryArguments: () => JsonSerializer.SerializeToElement(new { databaseId = "db", query = "SELECT missing_metric FROM metrics" })));
            string text = string.Join("\n", logs);
            Assert.Equal(1, lookups); Assert.Contains("Unknown column missing_metric", text);
            Assert.Contains("status=failure_result rowsReturned=unknown", text); Assert.DoesNotContain("rowsReturned=0", text);
        }

        [Fact]
        public async Task DiagnosticArgumentOrSinkFailureCannotPreventTheRealQuery()
        {
            var result = new QueryResult { RowsReturned = 2 };
            Assert.Same(result, await McpToolDiagnostics.InvokeAsync("execute_query", () => Task.FromResult<object>(result), _ => throw new Exception(), _ => throw new Exception(),
                queryArguments: () => throw new InvalidOperationException("diagnostic argument failure")));
        }

        [Fact]
        public async Task QueryArgumentLoggingDoesNotMutateTheSqlPassedToTheHandler()
        {
            JsonElement input = JsonSerializer.SerializeToElement(new { databaseId = "db", query = " SELECT 1; " });
            await McpToolDiagnostics.InvokeAsync("execute_query", () =>
            {
                Assert.Equal(" SELECT 1; ", input.GetProperty("query").GetString());
                return Task.FromResult<object>(new QueryResult { RowsReturned = 1 });
            }, _ => { }, _ => { }, queryArguments: () => input);
        }

        [Fact]
        public async Task CredentialLookupFailureWithholdsSqlButDoesNotPreventTheQuery()
        {
            var info = new List<string>();
            await McpToolDiagnostics.InvokeAsync("execute_query", () => Task.FromResult<object>(new QueryResult { RowsReturned = 3 }), info.Add, _ => { },
                resolveSecrets: () => throw new InvalidOperationException(),
                queryArguments: () => JsonSerializer.SerializeToElement(new { databaseId = "db", query = "SELECT 'new-unlabelled-secret'" }));
            string text = string.Join("\n", info);
            Assert.DoesNotContain("new-unlabelled-secret", text); Assert.Contains("credential lookup failed", text); Assert.Contains("rowsReturned=3", text);
        }

        [Fact]
        public async Task MultilineSqlKeepsEscapedNewlinesSoLineCommentsRemainMeaningful()
        {
            var info = new List<string>();
            await McpToolDiagnostics.InvokeAsync("execute_query", () => Task.FromResult<object>(new QueryResult { RowsReturned = 2 }), info.Add, _ => { },
                queryArguments: () => JsonSerializer.SerializeToElement(new { databaseId = "db", query = "SELECT 1\n-- note\nUNION ALL SELECT 2" }));
            string text = string.Join("|", info);
            Assert.Contains("sql=\"SELECT 1\\n-- note\\nUNION ALL SELECT 2\"", text); Assert.DoesNotContain("\n", text);
        }

        [Fact]
        public async Task DatabaseNameLookupFailureDoesNotHideSqlOrStopExecution()
        {
            var info = new List<string>();
            await McpToolDiagnostics.InvokeAsync("execute_query", () => Task.FromResult<object>(new QueryResult { RowsReturned = 1 }), info.Add, _ => { },
                queryArguments: () => JsonSerializer.SerializeToElement(new { databaseId = "db", query = "SELECT 1" }),
                resolveDatabase: _ => throw new InvalidOperationException("metadata read failed"));
            string text = string.Join("\n", info);
            Assert.Contains("databaseName=\"[unavailable]\"", text); Assert.Contains("sql=\"SELECT 1\"", text); Assert.Contains("rowsReturned=1", text);
        }

        [Fact]
        public async Task LogArgumentsFollowTheSameCaseInsensitiveLastPropertyWinsRuleAsExecution()
        {
            var info = new List<string>();
            using JsonDocument arguments = JsonDocument.Parse("{\"databaseId\":\"wrong_db\",\"DatabaseId\":\"actual_db\",\"query\":\"SELECT 1\",\"Query\":\"SELECT 2\"}");
            await McpToolDiagnostics.InvokeAsync("execute_query", () => Task.FromResult<object>(new QueryResult { RowsReturned = 1 }), info.Add, _ => { },
                queryArguments: () => arguments.RootElement,
                resolveDatabase: id => { Assert.Equal("actual_db", id); return Task.FromResult(new DatabaseEntry { DatabaseName = "metrics", Name = "Metrics" }); });
            string text = string.Join("\n", info);
            Assert.Contains("sql=\"SELECT 2\"", text); Assert.Contains("databaseId=\"actual_db\"", text); Assert.DoesNotContain("wrong_db", text);
        }

        [Fact]
        public async Task SqliteDatabaseIdentityFallsBackToTheActualFileBeforeTheDisplayLabel()
        {
            var info = new List<string>();
            await McpToolDiagnostics.InvokeAsync("execute_query", () => Task.FromResult<object>(new QueryResult { RowsReturned = 1 }), info.Add, _ => { },
                queryArguments: () => JsonSerializer.SerializeToElement(new { databaseId = "db", query = "SELECT 1" }),
                resolveDatabase: _ => Task.FromResult(new DatabaseEntry { Filename = "/data/report.db", Name = "Report display name" }));
            string text = string.Join("\n", info);
            Assert.Contains("databaseName=\"/data/report.db\"", text); Assert.Contains("databaseLabel=\"Report display name\"", text);
        }

        [Theory]
        [InlineData("SELECT 'my''password'", "my'password")]
        [InlineData("SELECT 'my\\'password'", "my'password")]
        [InlineData("SELECT 'my\\\\password'", "my\\password")]
        public void ConfiguredCredentialsInsideEscapedSqlLiteralsAreStillHidden(string sql, string password)
        {
            Assert.Equal("SELECT '[redacted]'", CredentialLogRedactor.Redact(sql, new[] { password }, preserveControlCharacters: true));
        }
    }
}
