namespace Test.Xunit
{
    using System;
    using System.IO;
    using System.Linq;
    using System.Net;
    using System.Net.Sockets;
    using System.Net.Http;
    using System.Text.Json;
    using System.Text.Json.Nodes;
    using System.Threading;
    using System.Threading.Tasks;
    using Microsoft.Data.Sqlite;
    using Tablix.Core.Enums;
    using Tablix.Core.Helpers;
    using Tablix.Core.Persistence.Sqlite;
    using Tablix.Core.Settings;
    using Tablix.Server;
    using Tablix.Server.Observability;
    using Test.Shared;
    using global::Xunit;

    /// <summary>Real MCP requests with telemetry disabled and normal info-level application logs.</summary>
    public sealed class McpDiagnosticsTests
    {
        /// <summary>Old configurations retain the shared hostname until an MCP override is provided.</summary>
        [Fact]
        public void McpHostnameOverrideSurvivesConfigurationRoundTrip()
        {
            RestSettings settings = Serializer.DeserializeJson<RestSettings>("{\"Hostname\":\"127.0.0.1\",\"McpHostname\":\"*\"}");
            JsonObject result = JsonNode.Parse(Serializer.SerializeJson(settings)).AsObject();
            Assert.Equal("127.0.0.1", result["Hostname"].GetValue<string>());
            Assert.Equal("*", result["McpHostname"]?.GetValue<string>());
        }

        /// <summary>The production override exposes MCP on another loopback address but not the REST API.</summary>
        [Fact]
        public async Task IndependentMcpListenerWorksWhileRestRemainsOnItsLoopbackAddress()
        {
            int restPort = 0;
            await WithServerAsync(async (session, state, logs) =>
            {
                using JsonDocument response = await CallAsync(session, new { maxResults = 100, skip = 0, filter = "" });
                Assert.False(IsError(response), response.RootElement.GetRawText());
                Assert.Contains("fixture_db", response.RootElement.GetRawText());
                using HttpClient client = new HttpClient(new HttpClientHandler { UseProxy = false }) { Timeout = TimeSpan.FromSeconds(2) };
                using HttpResponseMessage local = await client.GetAsync("http://127.0.0.1:" + restPort + "/");
                Assert.True(local.IsSuccessStatusCode);
                try
                {
                    using HttpResponseMessage other = await client.GetAsync("http://127.0.0.2:" + restPort + "/");
                    Assert.False(other.IsSuccessStatusCode, "REST must not serve the other interface/address.");
                }
                catch (HttpRequestException) { }
                catch (TaskCanceledException) { }
            }, configure: settings =>
            {
                restPort = settings["Rest"]["Port"].GetValue<int>();
                settings["Rest"]["McpHostname"] = "*";
            }, mcpConnectionHost: "127.0.0.2");
        }
        /// <summary>Configured stdout works without an interactive terminal, with either file setting.</summary>
        [Theory]
        [InlineData(true)]
        [InlineData(false)]
        public async Task ConsoleLogsRemainVisibleWithoutInteractiveTerminal(bool fileLogging)
        {
            TextWriter previous = Console.Out;
            using StringWriter output = new StringWriter();
            try
            {
                Console.SetOut(TextWriter.Synchronized(output));
                await WithServerAsync(async (session, state, logs) =>
                {
                    using JsonDocument response = await CallAsync(session, new { maxResults = 100, skip = 0, filter = "" });
                    Assert.False(IsError(response));
                }, consoleLogging: true, fileLogging: fileLogging);
                Assert.Contains("[MCP]", output.ToString());
                Assert.Contains("status=success", output.ToString());
            }
            finally { Console.SetOut(previous); }
        }
        [Fact]
        public async Task LoggingFailureDoesNotReplaceTheToolException()
        {
            InvalidOperationException original = new InvalidOperationException("secret SQL payload and credentials");
            Exception result = await Assert.ThrowsAsync<InvalidOperationException>(() => McpToolDiagnostics.InvokeAsync("fixture", () => throw original, _ => throw new Exception("logger failed"), _ => throw new Exception("logger failed")));
            Assert.Same(original, result);
        }
        [Fact]
        public void DiagnosticDescriptionKeepsMessagesButOmitsCredentialsAndExceptionData()
        {
            Exception source = new InvalidOperationException("password=diagnostic-secret-password query=SELECT private_value FROM business"); source.Data["secret"] = "private-row";
            string generic = McpToolDiagnostics.Describe(source);
            Assert.Contains("InvalidOperationException", generic); Assert.DoesNotContain("diagnostic-secret-password", generic); Assert.DoesNotContain("private-row", generic); Assert.Contains("SELECT private_value FROM business", generic);
            string schema = McpToolDiagnostics.Describe(new SqliteException("SQLite Error 1: 'no such table: api_secret_token'.", 1), new[] { "api_secret_token" });
            Assert.Contains("sqliteCode=1", schema); Assert.DoesNotContain("api_secret_token", schema); Assert.Contains("[redacted]", schema);
        }
        [Fact]
        public async Task DiscoverDatabasesAcceptsTheNumericParametersFromTheUserInterface()
        {
            await WithServerAsync(async (session, state, logs) =>
            {
                using JsonDocument response = await CallAsync(session, new { maxResults = 100, skip = 0, filter = "" });
                Assert.False(IsError(response), response.RootElement.GetRawText());
                string content = response.RootElement.GetProperty("result").GetProperty("content")[0].GetProperty("text").GetString();
                Assert.Contains("fixture_db", content);
            });
        }
        [Fact]
        public async Task HandlerFailureAppearsInInfoLevelLogsWhileClientErrorStaysGeneric()
        {
            await WithServerAsync(async (session, state, logs) =>
            {
                using (SqliteConnection connection = new SqliteConnection("Data Source=" + state + ";Pooling=False"))
                {
                    await connection.OpenAsync(); using SqliteCommand command = connection.CreateCommand();
                    command.CommandText = "PRAGMA foreign_keys=OFF; DROP TABLE database_connections"; await command.ExecuteNonQueryAsync();
                }
                using JsonDocument response = await CallAsync(session, new { maxResults = 100, skip = 0, filter = "" });
                Assert.True(IsError(response)); Assert.Contains("internal error", response.RootElement.GetRawText());
                Assert.DoesNotContain("no such table", response.RootElement.GetRawText());
                string text = "";
                for (int i = 0; i < 20; i++)
                {
                    text = string.Join("\n", Directory.GetFiles(logs).Select(File.ReadAllText));
                    if (text.Contains("SqliteException", StringComparison.Ordinal)) break;
                    await Task.Delay(50);
                }
                Assert.Contains("[MCP]", text); Assert.Contains("tablix_discover_databases", text);
                Assert.Contains("SqliteException", text); Assert.Contains("failed", text);
                Assert.Contains("credential lookup failed", text); Assert.Contains("sqliteCode=1", text);
                Assert.DoesNotContain("diagnostic-secret-password", text);
            });
        }

        [Fact]
        public async Task FailedQueryDetailsPersistAcrossServerRestarts()
        {
            string retained = Path.Combine(Path.GetTempPath(), "tablix-persistent-log-" + Guid.NewGuid().ToString("N"));
            try
            {
                for (int attempt = 1; attempt <= 2; attempt++)
                {
                    string missing = "missing_metric_" + attempt;
                    await WithServerAsync(async (session, state, logs) =>
                    {
                        using JsonDocument response = await CallAsync(session, new { databaseId = "fixture_db", query = "SELECT " + missing + " FROM sample" }, "tablix_execute_query");
                        Assert.Contains(missing, response.RootElement.GetRawText());
                        string text = await ReadLogsUntilAsync(logs, missing);
                        Assert.Contains(missing, text); Assert.Contains("status=failure_result", text); Assert.Contains("fixture_db", text);
                        if (attempt == 2) Assert.Contains("missing_metric_1", text);
                    }, retainedRoot: retained);
                }
            }
            finally { if (Directory.Exists(retained)) Directory.Delete(retained, true); }
        }

        [Fact]
        public async Task FailureLogsRedactTheRegisteredDatabasePasswordEvenWithoutAPasswordLabel()
        {
            await WithServerAsync(async (session, state, logs) =>
            {
                using JsonDocument response = await CallAsync(session, new { databaseId = "fixture_db", query = "SELECT [diagnostic-secret-password] FROM sample" }, "tablix_execute_query");
                Assert.Contains("diagnostic-secret-password", response.RootElement.GetRawText());
                string text = await ReadLogsUntilAsync(logs, "status=failure_result");
                Assert.Contains("no such column", text); Assert.Contains("[redacted]", text);
                Assert.DoesNotContain("diagnostic-secret-password", text);
            });
        }

        [Fact]
        public async Task RealQuerySqlAndRowsAreWrittenToStdoutAndPersistentFile()
        {
            TextWriter previous = Console.Out; using StringWriter output = new StringWriter();
            try
            {
                Console.SetOut(TextWriter.Synchronized(output));
                await WithServerAsync(async (session, state, logs) =>
                {
                    const string sql = "SELECT 1 AS business_metric UNION ALL SELECT 2 UNION ALL SELECT 3";
                    using JsonDocument response = await CallAsync(session, new { databaseId = "fixture_db", query = " " + sql + "; " }, "db_execute_query");
                    Assert.False(IsError(response));
                    string text = "";
                    for (int i = 0; i < 50; i++)
                    {
                        text = string.Join("\n", Directory.GetFiles(logs).Select(File.ReadAllText));
                        if (text.Contains("rowsReturned=3", StringComparison.Ordinal)) break;
                        await Task.Delay(50);
                    }
                    foreach (string sink in new[] { text, output.ToString() })
                    {
                        Assert.Contains("tool=db_execute_query", sink); Assert.Contains("sql=\"" + sql + "\"", sink);
                        Assert.Contains("databaseId=\"fixture_db\"", sink); Assert.Contains("status=success rowsReturned=3", sink);
                        Assert.Contains("databaseName=\"fixture_metrics\"", sink); Assert.Contains("databaseLabel=\"Fixture\"", sink);
                    }
                }, consoleLogging: true, configure: settings => settings["Mcp"]["ToolNamePrefix"] = "db_");
            }
            finally { Console.SetOut(previous); }
        }

        private static async Task<string> ReadLogsUntilAsync(string logs, string expected)
        {
            string text = "";
            for (int i = 0; i < 50; i++)
            {
                text = string.Join("\n", Directory.GetFiles(logs).Select(File.ReadAllText));
                if (text.Contains(expected, StringComparison.Ordinal) && text.Contains("status=failure_result", StringComparison.Ordinal)) break;
                await Task.Delay(50);
            }
            return text;
        }
        private static async Task WithServerAsync(Func<McpTestSession, string, string, Task> body, bool consoleLogging = false, bool fileLogging = true,
            Action<JsonObject> configure = null, string mcpConnectionHost = "127.0.0.1", string retainedRoot = null)
        {
            string root = retainedRoot ?? Path.Combine(Path.GetTempPath(), "tablix-diagnostic-" + Guid.NewGuid().ToString("N")); Directory.CreateDirectory(root);
            string state = Path.Combine(root, "state.db"), logs = Path.Combine(root, "logs"); Directory.CreateDirectory(logs);
            string database = Path.Combine(root, "fixture.db");
            using (SqliteConnection connection = new SqliteConnection("Data Source=" + database + ";Pooling=False"))
            {
                connection.Open(); using SqliteCommand cmd = connection.CreateCommand(); cmd.CommandText = "CREATE TABLE IF NOT EXISTS sample(id INTEGER)"; cmd.ExecuteNonQuery();
            }
            await using (SqliteDatabaseDriver driver = new SqliteDatabaseDriver(state))
            {
                await driver.InitializeAsync();
                if (await driver.DatabaseConnections.ReadAsync("fixture_db") == null)
                    await driver.DatabaseConnections.CreateAsync(new DatabaseEntry { Id = "fixture_db", Name = "Fixture", DatabaseName = "fixture_metrics", Type = DatabaseTypeEnum.Sqlite, Filename = database, Password = "diagnostic-secret-password" });
                await driver.DatabaseConnections.DeleteAsync("db_sample_sqlite");
            }
            using (SqliteConnection connection = new SqliteConnection("Data Source=" + state + ";Pooling=False"))
            {
                connection.Open(); using SqliteCommand cmd = connection.CreateCommand(); cmd.CommandText = "UPDATE model_providers SET enabled=0,health_check_enabled=0"; cmd.ExecuteNonQuery();
            }
            TablixSettings settings = new TablixSettings(); settings.Persistence.Filename = state;
            settings.Rest.Hostname = "127.0.0.1"; settings.Rest.Port = Port(); do { settings.Rest.McpPort = Port(); } while (settings.Rest.McpPort == settings.Rest.Port);
            settings.Chat.Enabled = false; settings.Telemetry.Enable = false; settings.Telemetry.OtlpEnable = false; settings.Telemetry.PrometheusEnable = false;
            settings.Logging.ConsoleLogging = consoleLogging; settings.Logging.FileLogging = fileLogging; settings.Logging.LogDirectory = logs + Path.DirectorySeparatorChar; settings.Logging.MinimumSeverity = 1;
            string path = Path.Combine(root, "tablix.json");
            JsonObject configuration = JsonNode.Parse(Serializer.SerializeJson(settings)).AsObject();
            configure?.Invoke(configuration);
            File.WriteAllText(path, configuration.ToJsonString());
            TablixServer server = new TablixServer(path); using CancellationTokenSource timeout = new CancellationTokenSource(TimeSpan.FromSeconds(30));
            try
            {
                await server.StartAsync(timeout.Token);
                McpTestSession session = await McpTestSession.OpenAsync("http://" + mcpConnectionHost + ":" + settings.Rest.McpPort + "/mcp", timeout.Token);
                await body(session, state, logs);
            }
            finally
            {
                timeout.Cancel(); await server.StopAsync();
                using SqliteConnection fixture = new SqliteConnection("Data Source=" + database); SqliteConnection.ClearPool(fixture);
                if (retainedRoot == null) Directory.Delete(root, true);
            }
        }
        private static int Port() { TcpListener tcp = new TcpListener(IPAddress.Loopback, 0); tcp.Start(); int port = ((IPEndPoint)tcp.LocalEndpoint).Port; tcp.Stop(); return port; }
        private static bool IsError(JsonDocument response) => response.RootElement.TryGetProperty("error", out _) || response.RootElement.GetProperty("result").TryGetProperty("isError", out JsonElement error) && error.GetBoolean();
        private static async Task<JsonDocument> CallAsync(McpTestSession session, object arguments, string tool = "tablix_discover_databases")
        {
            string response = await session.PostAsync(JsonSerializer.Serialize(new { jsonrpc = "2.0", id = 1, method = "tools/call", @params = new { name = tool, arguments } }), CancellationToken.None);
            if (!response.TrimStart().StartsWith("{", StringComparison.Ordinal)) response = response.Split('\n').Select(x => x.Trim()).Last(x => x.StartsWith("data:", StringComparison.Ordinal)).Substring(5).Trim();
            return JsonDocument.Parse(response);
        }
    }
}
