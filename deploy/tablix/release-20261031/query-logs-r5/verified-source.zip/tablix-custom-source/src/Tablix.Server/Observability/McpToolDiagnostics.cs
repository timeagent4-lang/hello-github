namespace Tablix.Server.Observability
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Linq;
    using System.Data.Common;
    using System.Text.Encodings.Web;
    using System.Text.Json;
    using System.Text.RegularExpressions;
    using System.Threading.Tasks;
    using Microsoft.Data.Sqlite;
    using Tablix.Core.Helpers;
    using Tablix.Core.Models;
    using Tablix.Core.Settings;

    /// <summary>Application logs for MCP calls, independent of external telemetry exporters.</summary>
    public static class McpToolDiagnostics
    {
        private static readonly JsonSerializerOptions LogJson = new JsonSerializerOptions { Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping };

        /// <summary>Log tool failures with credential-redacted details; results and exceptions pass through unchanged.</summary>
        public static async Task<object> InvokeAsync(string toolName, Func<Task<object>> handler, Action<string> info, Action<string> warning, IEnumerable<string> secrets = null,
            Func<Task<IEnumerable<string>>> resolveSecrets = null, Func<object> queryArguments = null,
            Func<string, Task<DatabaseEntry>> resolveDatabase = null)
        {
            string requestId = Guid.NewGuid().ToString("N"); long started = Stopwatch.GetTimestamp(); string outcome = "success";
            int? rowsReturned = null;
            string queryIdentity = "";
            Task<(IEnumerable<string> Values, bool Complete)> credentialTask = null;
            Task<(IEnumerable<string> Values, bool Complete)> Credentials() => credentialTask ??= ResolveSecretsAsync(secrets, resolveSecrets);
            Write(info, "[MCP] requestId=" + requestId + " tool=" + toolName + " started");
            try
            {
                if (queryArguments != null)
                {
                    var credentials = await Credentials().ConfigureAwait(false);
                    var details = await DescribeQueryAsync(queryArguments, resolveDatabase, credentials.Values, credentials.Complete).ConfigureAwait(false);
                    queryIdentity = details.Identity;
                    Write(info, "[MCP] requestId=" + requestId + " tool=" + toolName + " query_received " + queryIdentity + " sql=" + details.Sql);
                }
                object result = await handler().ConfigureAwait(false);
                if (result is QueryResult query && query.Success) rowsReturned = query.RowsReturned;
                if (McpTelemetry.ReportsFailure(result))
                {
                    outcome = "failure_result";
                    var credentials = await Credentials().ConfigureAwait(false);
                    Write(warning, "[MCP] requestId=" + requestId + " tool=" + toolName + " failure_result " + DescribeResult(result, credentials.Values, credentials.Complete));
                }
                return result;
            }
            catch (Exception ex)
            {
                outcome = ex is OperationCanceledException ? "canceled" : "failed";
                var credentials = await Credentials().ConfigureAwait(false);
                Write(warning, "[MCP] requestId=" + requestId + " tool=" + toolName + " failed " + Describe(ex, credentials.Values, credentials.Complete));
                throw;
            }
            finally
            {
                string rows = queryArguments != null ? " rowsReturned=" + (rowsReturned?.ToString(System.Globalization.CultureInfo.InvariantCulture) ?? "unknown") : "";
                Write(info, "[MCP] requestId=" + requestId + " tool=" + toolName + " completed status=" + outcome + rows + " elapsedMs=" + Stopwatch.GetElapsedTime(started).TotalMilliseconds.ToString("F1", System.Globalization.CultureInfo.InvariantCulture) + (queryIdentity.Length == 0 ? "" : " " + queryIdentity));
            }
        }

        /// <summary>Preserve actionable messages and codes while redacting credentials and excluding exception Data.</summary>
        public static string Describe(Exception exception, IEnumerable<string> secrets = null, bool credentialsComplete = true)
        {
            try
            {
                List<string> parts = new List<string>(); int depth = 0;
                for (Exception ex = exception; ex != null && depth++ < 4; ex = ex.InnerException)
                {
                    parts.Add("exception=" + ex.GetType().FullName);
                    parts.Add("message=" + Quote(credentialsComplete ? ex.Message : "[withheld: credential lookup failed]", secrets));
                    if (ex is JsonException json)
                        parts.Add("jsonPath=" + Quote(credentialsComplete ? json.Path : "[withheld]", secrets) + " line=" + json.LineNumber + " byte=" + json.BytePositionInLine);
                    if (ex is SqliteException sqlite)
                    {
                        parts.Add("sqliteCode=" + sqlite.SqliteErrorCode + " sqliteExtendedCode=" + sqlite.SqliteExtendedErrorCode);
                    }
                    if (ex is DbException database) parts.Add("databaseCode=" + database.ErrorCode + " sqlState=" + Quote(credentialsComplete ? database.SqlState : "[withheld]", secrets));
                    StackFrame[] frames = new StackTrace(ex, true).GetFrames();
                    if (frames != null)
                    {
                        parts.Add("at=" + string.Join(" <- ", frames.Take(6).Select(frame =>
                        {
                            var method = frame.GetMethod(); return (method?.DeclaringType?.FullName ?? "unknown") + "." + method?.Name + ":" + frame.GetFileLineNumber();
                        })));
                    }
                }
                string text = Regex.Replace(string.Join(" ", parts), @"[\x00-\x1f\x7f]", " ");
                return text.Length > 20000 ? text.Substring(0, 20000) + " [truncated]" : text;
            }
            catch { return "exception=" + exception?.GetType().Name + " diagnostic-format-failed"; }
        }
        private static async Task<(string Identity, string Sql)> DescribeQueryAsync(Func<object> read, Func<string, Task<DatabaseEntry>> resolveDatabase, IEnumerable<string> secrets, bool credentialsComplete)
        {
            try
            {
                if (read() is not JsonElement arguments || arguments.ValueKind != JsonValueKind.Object)
                    return ("", "\"[unavailable: invalid query arguments]\"");
                McpExecuteQueryRequest request = Serializer.DeserializeObject<McpExecuteQueryRequest>(arguments);
                string database = request?.DatabaseId ?? "";
                string sql = request?.Query ?? "";
                DatabaseEntry entry = null;
                if (resolveDatabase != null && !string.IsNullOrEmpty(database))
                {
                    try { entry = await resolveDatabase(database).ConfigureAwait(false); }
                    catch { /* Log the submitted SQL even if the optional name lookup fails. */ }
                }
                string identity = "databaseName=" + Quote(entry?.DatabaseName ?? entry?.Filename ?? entry?.Name ?? "[unavailable]", secrets)
                    + " databaseLabel=" + Quote(entry?.Name ?? "[unavailable]", secrets) + " databaseId=" + Quote(database, secrets);
                return (identity, Quote(credentialsComplete ? QueryValidator.NormalizeSingleStatement(sql) : "[withheld: credential lookup failed]", secrets, preserveSqlLineBreaks: true));
            }
            catch { return ("", "\"[unavailable: diagnostic argument read failed]\""); }
        }
        private static string DescribeResult(object result, IEnumerable<string> secrets, bool credentialsComplete)
        {
            try
            {
                string database = result.GetType().GetProperty("DatabaseId")?.GetValue(result) as string;
                string error = result.GetType().GetProperty("Error")?.GetValue(result) as string;
                return "databaseId=" + Quote(database, secrets) + " error=" + Quote(credentialsComplete ? error ?? "Tool reported Success=false without an Error message." : "[withheld: credential lookup failed]", secrets);
            }
            catch { return "error=\"Failure details unavailable\""; }
        }
        private static string Quote(string value, IEnumerable<string> secrets, bool preserveSqlLineBreaks = false) => JsonSerializer.Serialize(CredentialLogRedactor.Redact(value ?? "", secrets, preserveSqlLineBreaks), LogJson);

        private static async Task<(IEnumerable<string> Values, bool Complete)> ResolveSecretsAsync(IEnumerable<string> known, Func<Task<IEnumerable<string>>> resolve)
        {
            try
            {
                var values = (known ?? Array.Empty<string>()).ToList();
                if (resolve != null) values.AddRange(await resolve().ConfigureAwait(false) ?? Array.Empty<string>());
                return (values, true);
            }
            catch { return (Array.Empty<string>(), false); }
        }
        private static void Write(Action<string> sink, string message) { try { sink?.Invoke(message); } catch { } }
    }
}
