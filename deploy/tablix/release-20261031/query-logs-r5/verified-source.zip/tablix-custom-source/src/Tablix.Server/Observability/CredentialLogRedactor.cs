namespace Tablix.Server.Observability
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Text.Json;
    using System.Text.RegularExpressions;

    /// <summary>Redact credentials only; retain database addresses, SQL and business identifiers for diagnosis.</summary>
    public static class CredentialLogRedactor
    {
        private const RegexOptions Options = RegexOptions.IgnoreCase | RegexOptions.CultureInvariant | RegexOptions.NonBacktracking;
        private static readonly Regex Authorization = new Regex(@"(?<prefix>\bAuthorization\s*[:=]\s*)(?:Bearer|Basic)\s+[^\s,;""'}]+", Options, TimeSpan.FromMilliseconds(100));
        private static readonly Regex UriCredentials = new Regex(@"(?<prefix>[a-z][a-z0-9+.-]*://)[^\s/]+@", Options, TimeSpan.FromMilliseconds(100));
        private static readonly Regex CredentialValue = new Regex("""(?<prefix>["']?\b(?:password|passwd|pwd|passphrase|api[_ -]?key|access[_ -]?token|refresh[_ -]?token|id[_ -]?token|token|client[_ -]?secret|authorization|connection[_ -]?string)\b["']?\s*[:=]\s*)(?:\[redacted\]|"(?:""|\\.|[^"\\])*"|'(?:''|\\.|[^'\\])*'|[^;\s,&}\]]+)""", Options, TimeSpan.FromMilliseconds(100));

        /// <summary>Handle labelled credentials, URI userinfo and configured values, including encoded forms.</summary>
        public static string Redact(string text, IEnumerable<string> secrets = null, bool preserveControlCharacters = false)
        {
            try
            {
                text ??= "";
                var values = new HashSet<string>(StringComparer.Ordinal);
                foreach (string secret in secrets ?? Array.Empty<string>())
                {
                    if (string.IsNullOrEmpty(secret)) continue;
                    values.Add(secret); values.Add(Uri.EscapeDataString(secret)); values.Add(WebUtility.UrlEncode(secret));
                    values.Add(secret.Replace("'", "''", StringComparison.Ordinal));
                    values.Add(secret.Replace("\"", "\"\"", StringComparison.Ordinal));
                    values.Add(secret.Replace("\\", "\\\\", StringComparison.Ordinal).Replace("'", "\\'", StringComparison.Ordinal)
                        .Replace("\"", "\\\"", StringComparison.Ordinal).Replace("\0", "\\0", StringComparison.Ordinal)
                        .Replace("\n", "\\n", StringComparison.Ordinal).Replace("\r", "\\r", StringComparison.Ordinal));
                    string json = JsonSerializer.Serialize(secret); values.Add(json.Substring(1, json.Length - 2));
                }
                foreach (string value in values.OrderByDescending(value => value.Length))
                    text = text.Replace(value, "[redacted]", StringComparison.Ordinal);
                text = Authorization.Replace(text, "${prefix}[redacted]");
                text = UriCredentials.Replace(text, "${prefix}[redacted]@");
                text = CredentialValue.Replace(text, "${prefix}[redacted]");
                if (!preserveControlCharacters) text = Regex.Replace(text, @"[\x00-\x1f\x7f]", " ");
                return text.Length > 16384 ? text.Substring(0, 16384) + " [truncated]" : text;
            }
            catch { return "[withheld: credential redaction failed]"; }
        }
    }
}
