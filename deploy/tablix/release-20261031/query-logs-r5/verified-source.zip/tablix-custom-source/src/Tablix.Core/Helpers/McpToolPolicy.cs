namespace Tablix.Core.Helpers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text.RegularExpressions;
    using Tablix.Core.Settings;

    /// <summary>
    /// Validated, immutable startup snapshot of MCP naming and tool exposure.
    /// </summary>
    public sealed class McpToolPolicy
    {
        private static readonly string[] _Identifiers = new[]
        {
            "discover_databases", "discover_database", "list_tables", "discover_table", "list_relationships",
            "execute_query", "get_database_context", "get_table_context", "update_context",
            "update_database_context", "update_table_context", "get_database_intelligence", "get_agent_pack"
        };
        private static readonly HashSet<string> _KnownTools = new HashSet<string>(_Identifiers, StringComparer.Ordinal);
        private static readonly Regex _ToolReferences = new Regex(
            @"\btablix_(?<tool>" + String.Join("|", _Identifiers.OrderByDescending(identifier => identifier.Length)) + @")\b",
            RegexOptions.CultureInvariant);
        private readonly string _ToolNamePrefix;
        private readonly HashSet<string> _DisabledTools;

        /// <summary>
        /// Validate settings and copy them for use until the next server restart.
        /// </summary>
        /// <param name="settings">MCP settings.</param>
        public McpToolPolicy(McpSettings settings)
        {
            if (settings == null) throw new ArgumentException("Mcp must be a settings object.", nameof(settings));
            if (settings.ToolNamePrefix == null || !Regex.IsMatch(settings.ToolNamePrefix, @"\A[A-Za-z0-9_-]*\z", RegexOptions.CultureInvariant))
                throw new ArgumentException("Mcp.ToolNamePrefix permits only ASCII letters, digits, underscores, and hyphens, or an empty string.", nameof(settings));
            if (settings.ToolNamePrefix.Length + _Identifiers.Max(identifier => identifier.Length) > 64)
                throw new ArgumentException("Mcp.ToolNamePrefix must produce tool names of at most 64 characters; the prefix may contain at most 39 characters.", nameof(settings));
            if (settings.DisabledTools == null)
                throw new ArgumentException("Mcp.DisabledTools must be an array of canonical tool suffixes; use [] to enable every tool.", nameof(settings));
            foreach (string identifier in settings.DisabledTools)
            {
                if (identifier == null || !_KnownTools.Contains(identifier))
                    throw new ArgumentException("Mcp.DisabledTools contains unknown canonical tool suffix '" + (identifier ?? "<null>") + "'. Use exact suffixes without a prefix. Known suffixes: " + String.Join(", ", _Identifiers) + ".", nameof(settings));
            }

            _ToolNamePrefix = settings.ToolNamePrefix;
            _DisabledTools = new HashSet<string>(settings.DisabledTools, StringComparer.Ordinal);
        }

        /// <summary>
        /// Return whether a canonical tool identifier is available.
        /// </summary>
        /// <param name="identifier">Canonical suffix.</param>
        /// <returns>True for a known, enabled tool.</returns>
        public bool IsEnabled(string identifier)
        {
            return identifier != null && _KnownTools.Contains(identifier) && !_DisabledTools.Contains(identifier);
        }

        /// <summary>
        /// Resolve a canonical suffix to its configured MCP name.
        /// </summary>
        /// <param name="identifier">Canonical suffix.</param>
        /// <returns>Configured tool name.</returns>
        public string GetToolName(string identifier)
        {
            if (identifier == null || !_KnownTools.Contains(identifier))
                throw new ArgumentException("Unknown MCP tool identifier '" + identifier + "'.", nameof(identifier));
            return _ToolNamePrefix + identifier;
        }

        /// <summary>
        /// Rewrite generated tool guidance to configured names and omit sentences recommending unavailable tools.
        /// This method is for generated descriptions, never saved user context or schema data.
        /// </summary>
        /// <param name="guidance">Generated guidance containing default tool names.</param>
        /// <returns>Guidance for the active tool policy.</returns>
        public string RewriteGuidance(string guidance)
        {
            if (String.IsNullOrEmpty(guidance)) return guidance;
            return String.Join(" ", Regex.Split(guidance, @"(?<=[.!?])\s+")
                .Where(sentence => _ToolReferences.Matches(sentence).Cast<Match>().All(match => IsEnabled(match.Groups["tool"].Value)))
                .Select(sentence => _ToolReferences.Replace(sentence, match => GetToolName(match.Groups["tool"].Value))));
        }
    }
}
