namespace Tablix.Core.Settings
{
    using System.Collections.Generic;

    /// <summary>
    /// MCP tool exposure settings, applied when the server starts.
    /// </summary>
    public class McpSettings
    {
        /// <summary>
        /// Prefix for every exposed tool name. May be empty; permits ASCII letters, digits, underscores, and hyphens.
        /// All canonical tool names must fit within 64 characters. Changes require a server restart.
        /// </summary>
        public string ToolNamePrefix { get; set; } = "tablix_";

        /// <summary>
        /// Exact, case-sensitive canonical tool suffixes to omit from registration, without a prefix.
        /// An empty list enables every tool. Null or unknown identifiers are rejected at startup.
        /// Changes require a server restart and do not affect REST or native chat tools.
        /// </summary>
        public List<string> DisabledTools { get; set; } = new List<string>
        {
            "update_context",
            "update_database_context",
            "update_table_context"
        };
    }
}
