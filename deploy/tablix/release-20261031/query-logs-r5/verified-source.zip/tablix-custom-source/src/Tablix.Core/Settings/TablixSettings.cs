namespace Tablix.Core.Settings
{
    using System.Collections.Generic;

    /// <summary>
    /// Root settings object for Tablix, serialized to/from tablix.json.
    /// </summary>
    public class TablixSettings
    {
        #region Public-Members

        /// <summary>
        /// REST and MCP server settings.
        /// </summary>
        public RestSettings Rest
        {
            get { return _Rest; }
            set { if (value != null) _Rest = value; }
        }

        /// <summary>
        /// MCP tool naming and exposure settings. Applied at startup.
        /// </summary>
        public McpSettings Mcp { get; set; } = new McpSettings();

        /// <summary>
        /// Logging settings.
        /// </summary>
        public LoggingSettings Logging
        {
            get { return _Logging; }
            set { if (value != null) _Logging = value; }
        }

        /// <summary>
        /// Product-state persistence database settings.
        /// </summary>
        public PersistenceDatabaseSettings Persistence
        {
            get { return _Persistence; }
            set { if (value != null) _Persistence = value; }
        }

        /// <summary>
        /// API keys for Bearer token authentication.
        /// </summary>
        public List<string> ApiKeys
        {
            get { return _ApiKeys; }
            set { _ApiKeys = value ?? new List<string>(); }
        }

        /// <summary>
        /// Chat and model provider settings.
        /// </summary>
        public ChatSettings Chat
        {
            get { return _Chat; }
            set { if (value != null) _Chat = value; }
        }

        /// <summary>
        /// Telemetry export settings (metrics, traces, and logs). Applied at startup.
        /// </summary>
        public TelemetrySettings Telemetry
        {
            get { return _Telemetry; }
            set { if (value != null) _Telemetry = value; }
        }

        #endregion

        #region Private-Members

        private RestSettings _Rest = new RestSettings();
        private LoggingSettings _Logging = new LoggingSettings();
        private PersistenceDatabaseSettings _Persistence = new PersistenceDatabaseSettings();
        private ChatSettings _Chat = new ChatSettings();
        private TelemetrySettings _Telemetry = new TelemetrySettings();
        private List<string> _ApiKeys = new List<string> { "tablixadmin" };

        #endregion

        #region Constructors-and-Factories

        /// <summary>
        /// Instantiate.
        /// </summary>
        public TablixSettings()
        {
        }

        #endregion
    }
}
