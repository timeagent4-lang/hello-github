using System.Text.Json.Nodes;
using System.Collections.Concurrent;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Diagnostics;
using System.Security.Cryptography;
using Microsoft.Data.Sqlite;
using Tablix.Deployment;

namespace Test.Deployment;

public sealed class DeploymentTests : IDisposable
{
    private readonly string root = Path.Combine(Path.GetTempPath(), "tablix-deploy-" + Guid.NewGuid().ToString("N"));
    private const string HostBase = "/srv/tablix";
    public DeploymentTests()
    {
        Directory.CreateDirectory(root);
        File.WriteAllText(Path.Combine(root, "tablix.json.template"), """
        {"ApiKeys":["__REST_API_KEY__"],"Persistence":{"Filename":"/data/tablix.db"},
        "Rest":{"Port":9100,"McpPort":9102,"Ssl":false},"Chat":{"Enabled":false},
        "Telemetry":{"Enable":false,"OtlpEnable":false,"PrometheusEnable":false,"LokiEnable":false,"ExportLogs":false}}
        """);
    }
    public void Dispose() { SqliteConnection.ClearAllPools(); Directory.Delete(root, true); }
    private async Task<(int Code, string Out, string Err)> Run(string command, string json = "[]", Dictionary<string, string>? env = null, params string[] extra)
    {
        using var output = new StringWriter(); using var error = new StringWriter();
        var code = await Program.RunAsync([command, "--base", root, "--host-base", HostBase, .. extra], new StringReader(json), output, error, env ?? new());
        return (code, output.ToString(), error.ToString());
    }
    private JsonObject Read(string file) => JsonNode.Parse(File.ReadAllText(Path.Combine(root, file)))!.AsObject();
    private void Save(string file, JsonObject node) => File.WriteAllText(Path.Combine(root, file), node.ToJsonString());
    private static JsonObject Container(string name = "legacy", string bind = "192.168.10.20", bool running = true, string source = "/srv/tablix/data", bool owned = true) => JsonNode.Parse(System.Text.Json.JsonSerializer.Serialize(new
    {
        Name = "/" + name, Config = new { Labels = new Dictionary<string, string> { ["com.tablix.offline.package"] = owned.ToString().ToLowerInvariant() } }, State = new { Running = running },
        Mounts = new[] { new { Source = source, Destination = "/data" } },
        NetworkSettings = new { Ports = new Dictionary<string, object> { ["9100/tcp"] = new[] { new { HostIp = bind, HostPort = "9100" } }, ["9102/tcp"] = new[] { new { HostIp = bind, HostPort = "7777" } } } }
    }))!.AsObject();
    private static string Snapshot(params JsonObject[] nodes) => new JsonArray(nodes.Select(n => n.DeepClone()).ToArray()).ToJsonString();

    [Fact] public async Task FreshConfigCreatesRandomKeyAndPrivateGatewayDefaults()
    {
        var result = await Run("prepare-config"); Assert.Equal(0, result.Code); Assert.Empty(result.Out);
        var cfg = Read("tablix.json"); var key = cfg["ApiKeys"]![0]!.GetValue<string>();
        Assert.Matches("^[0-9a-f]{64}$", key); Assert.Equal("tablix_", cfg["Mcp"]!["ToolNamePrefix"]!.GetValue<string>());
        Assert.Equal(3, cfg["Mcp"]!["DisabledTools"]!.AsArray().Count);
        var before = File.ReadAllBytes(Path.Combine(root, "tablix.json")); Assert.Equal(0, (await Run("prepare-config")).Code);
        Assert.Equal(before, File.ReadAllBytes(Path.Combine(root, "tablix.json")));
    }
    [Fact] public async Task ExistingKeysAndDeliberateMcpSettingsRemainUnchanged()
    {
        var cfg = Read("tablix.json.template"); cfg["ApiKeys"] = new JsonArray("existing-secret");
        cfg["Mcp"] = new JsonObject { ["ToolNamePrefix"] = "custom_", ["DisabledTools"] = new JsonArray() }; cfg["Context"] = "curated"; Save("tablix.json", cfg);
        Assert.Equal(0, (await Run("prepare-config")).Code); Assert.Equal(cfg.ToJsonString(), Read("tablix.json").ToJsonString());
    }
    [Fact] public async Task UnsafeConfigAndInvalidToolPolicyFailWithoutRewriting()
    {
        var cfg = Read("tablix.json.template"); cfg["ApiKeys"] = new JsonArray("secret"); cfg["Chat"]!["Enabled"] = true; Save("tablix.json", cfg);
        Assert.Equal(1, (await Run("prepare-config")).Code); Assert.True(Read("tablix.json")["Chat"]!["Enabled"]!.GetValue<bool>());
        cfg["Chat"]!["Enabled"] = false; cfg["Mcp"] = new JsonObject { ["ToolNamePrefix"] = "bad prefix", ["DisabledTools"] = new JsonArray("not_a_tool") }; Save("tablix.json", cfg);
        Assert.Equal(1, (await Run("prepare-config")).Code);
    }
    [Fact] public async Task MigrationPreservesPublishedBindingsAndMachineOutputIsExactlyFiveLines()
    {
        var result = await Run("resolve-deployment", Snapshot(Container())); Assert.Equal(0, result.Code);
        Assert.Equal("legacy\n192.168.10.20\n9100\n7777\ntablix-server:release-20261031\n", result.Out.Replace("\r", ""));
        Assert.Equal(7777, Read("deployment.local.json")["McpPort"]!.GetValue<int>());
    }
    [Fact] public async Task StoppedContainerUsesPersistentBindingsAndExplicitSettingsFixWildcard()
    {
        var item = Container(bind: "0.0.0.0", running: false); item["HostConfig"] = new JsonObject { ["PortBindings"] = item["NetworkSettings"]!["Ports"]!.DeepClone() }; item["NetworkSettings"]!["Ports"] = new JsonObject();
        Assert.Equal(1, (await Run("resolve-deployment", Snapshot(item))).Code); Assert.False(File.Exists(Path.Combine(root, "deployment.local.json")));
        Assert.Equal(0, (await Run("resolve-deployment", Snapshot(item), new() { ["TABLIX_BIND_IP"] = "127.0.0.1" })).Code);
        Assert.Equal(7777, Read("deployment.local.json")["McpPort"]!.GetValue<int>());
    }
    [Fact] public async Task RenamingWhileSameStateIsRunningFailsBeforeSaving()
    {
        var result = await Run("resolve-deployment", Snapshot(Container()), new() { ["TABLIX_CONTAINER_NAME"] = "new-name" });
        Assert.Equal(1, result.Code); Assert.False(File.Exists(Path.Combine(root, "deployment.local.json")));
    }
    [Theory] [InlineData("TABLIX_CONTAINER_NAME", "bad\nname")] [InlineData("TABLIX_IMAGE", "--help")] [InlineData("TABLIX_BIND_IP", "localhost")] [InlineData("TABLIX_MCP_PORT", "9100")] [InlineData("TABLIX_REST_PORT", "0")]
    public async Task InvalidDeploymentNeverWritesOrEmitsProtocol(string variable, string value)
    {
        var result = await Run("resolve-deployment", env: new() { [variable] = value }); Assert.Equal(1, result.Code); Assert.Empty(result.Out); Assert.False(File.Exists(Path.Combine(root, "deployment.local.json")));
    }
    [Fact] public async Task ExplicitEnvironmentCanRepairInvalidSavedPortsBeforeValidation()
    {
        Assert.Equal(0, (await Run("resolve-deployment")).Code); var cfg = Read("deployment.local.json"); cfg["McpPort"] = 0; Save("deployment.local.json", cfg);
        Assert.Equal(0, (await Run("resolve-deployment", env: new() { ["TABLIX_MCP_PORT"] = "7713" })).Code);
        Assert.Equal(7713, Read("deployment.local.json")["McpPort"]!.GetValue<int>());
    }
    [Theory] [InlineData("127.1")] [InlineData("2130706433")] [InlineData("01.2.3.4")] [InlineData("fe80::1%2")]
    public async Task NonCanonicalNumericIpIsRejected(string ip)
    {
        Assert.Equal(1, (await Run("resolve-deployment", env: new() { ["TABLIX_BIND_IP"] = ip })).Code);
        Assert.False(File.Exists(Path.Combine(root, "deployment.local.json")));
    }
    [Fact] public async Task GuardSelectsActualOwnedRunningNameOnStopAndRejectsForeignTarget()
    {
        Assert.Equal(0, (await Run("resolve-deployment")).Code);
        var stop = await Run("guard", Snapshot(Container()), extra: ["--stop"]); Assert.Equal(0, stop.Code); Assert.Equal("legacy\nrunning\n", stop.Out.Replace("\r", ""));
        Assert.Equal(1, (await Run("guard", Snapshot(Container("tablix-offline", owned: false)))).Code);
        Assert.Equal(1, (await Run("guard", Snapshot(Container("legacy"), Container("other")), extra: ["--stop"])).Code);
    }
    [Fact] public async Task InitializeFileRecognizesEmptyRetryAndNeverTruncatesExistingState()
    {
        Assert.Equal("1\n", (await Run("initialize-state-file")).Out.Replace("\r", ""));
        Assert.Equal("1\n", (await Run("initialize-state-file")).Out.Replace("\r", ""));
        File.WriteAllText(Path.Combine(root, "data", "tablix.db"), "existing");
        Assert.Equal("0\n", (await Run("initialize-state-file")).Out.Replace("\r", "")); Assert.Equal("existing", File.ReadAllText(Path.Combine(root, "data", "tablix.db")));
    }
    private SqliteConnection Seed(bool provider = true)
    {
        Directory.CreateDirectory(Path.Combine(root, "data")); var db = new SqliteConnection($"Data Source={Path.Combine(root, "data", "tablix.db")};Pooling=False"); db.Open();
        using var cmd = db.CreateCommand(); cmd.CommandText = """
            CREATE TABLE model_providers(id TEXT, enabled INTEGER, health_check_enabled INTEGER);
            CREATE TABLE database_connections(id TEXT); INSERT INTO database_connections VALUES('stable-id');
            CREATE TABLE database_allowed_queries(database_id TEXT, query_operation TEXT);
            INSERT INTO database_allowed_queries VALUES('db_sample_sqlite','SELECT'),('db_sample_sqlite','UPDATE'),('stable-id','UPDATE');
            CREATE TABLE contexts(id TEXT, context TEXT); INSERT INTO contexts VALUES('stable-id','curated context');
            """ + (provider ? "INSERT INTO model_providers VALUES('ollama',1,1);" : ""); cmd.ExecuteNonQuery(); return db;
    }
    [Fact] public async Task PrepareStateDisablesProvidersAndSampleWritesWhilePreservingIdsAndContext()
    {
        using (var db = Seed()) { }
        Assert.Equal(0, (await Run("prepare-state")).Code);
        using var read = new SqliteConnection($"Data Source={Path.Combine(root, "data", "tablix.db")};Pooling=False"); read.Open();
        using var cmd = read.CreateCommand(); cmd.CommandText = "SELECT enabled+health_check_enabled FROM model_providers"; Assert.Equal(0L, cmd.ExecuteScalar());
        cmd.CommandText = "SELECT context FROM contexts WHERE id='stable-id'"; Assert.Equal("curated context", cmd.ExecuteScalar());
        cmd.CommandText = "SELECT COUNT(*) FROM database_allowed_queries"; Assert.Equal(2L, cmd.ExecuteScalar());
    }
    [Fact] public async Task EmptyProviderTableRefusesNetworkedStart()
    {
        using (var db = Seed(false)) { }
        Assert.Equal(1, (await Run("prepare-state")).Code);
    }
    [Fact] public async Task HelperExecutesWithExactReleasedServerDepsAndRuntimeConfigIncludingSqlite()
    {
        string source = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "../../../../.."));
        string workspace = Path.GetDirectoryName(source)!;
        string released = Path.Combine(workspace, "build", "publish-linux"), runtime = Path.Combine(root, "runtime");
        Directory.CreateDirectory(runtime);
        foreach (string path in Directory.GetFiles(released, "*", SearchOption.AllDirectories))
        {
            string target = Path.Combine(runtime, Path.GetRelativePath(released, path)); Directory.CreateDirectory(Path.GetDirectoryName(target)!); File.Copy(path, target);
        }
        File.Copy(typeof(Program).Assembly.Location, Path.Combine(runtime, "Tablix.Deployment.dll"));
        // The released managed runtime/deps stay byte-identical. Windows needs its native SQLite binary for this host-only proof.
        if (OperatingSystem.IsWindows()) File.Copy(Path.Combine(AppContext.BaseDirectory, "runtimes", "win-x64", "native", "e_sqlite3.dll"), Path.Combine(runtime, "e_sqlite3.dll"));
        Assert.False(File.Exists(Path.Combine(runtime, "Tablix.Deployment.deps.json")));
        foreach (string file in new[] { "Tablix.Server.deps.json", "Tablix.Server.runtimeconfig.json" })
            Assert.Equal(SHA256.HashData(File.ReadAllBytes(Path.Combine(released, file))), SHA256.HashData(File.ReadAllBytes(Path.Combine(runtime, file))));
        using (var db = Seed()) { }
        foreach (string command in new[] { "prepare-config", "prepare-state", "fields" })
        {
            var start = new ProcessStartInfo(Path.Combine(workspace, "tools", "dotnet", OperatingSystem.IsWindows() ? "dotnet.exe" : "dotnet")) { RedirectStandardOutput = true, RedirectStandardError = true, UseShellExecute = false };
            foreach (string argument in new[] { "exec", "--depsfile", Path.Combine(runtime, "Tablix.Server.deps.json"), "--runtimeconfig", Path.Combine(runtime, "Tablix.Server.runtimeconfig.json"), Path.Combine(runtime, "Tablix.Deployment.dll"), command, "--base", root, "--host-base", HostBase }) start.ArgumentList.Add(argument);
            using var child = Process.Start(start)!; var stdout = child.StandardOutput.ReadToEndAsync(); var stderr = child.StandardError.ReadToEndAsync(); await child.WaitForExitAsync();
            Assert.True(child.ExitCode == 0, command + ": " + await stderr);
            if (command == "fields") Assert.Equal("tablix-offline\n127.0.0.1\n9100\n7713\ntablix-server:release-20261031\n", (await stdout).Replace("\r", ""));
            else Assert.Empty(await stdout);
        }
        using var read = new SqliteConnection($"Data Source={Path.Combine(root, "data", "tablix.db")};Pooling=False"); read.Open();
        using var check = read.CreateCommand(); check.CommandText = "SELECT enabled+health_check_enabled FROM model_providers"; Assert.Equal(0L, check.ExecuteScalar());
    }

    private async Task ConfigureConnection(bool include = true)
    {
        Assert.Equal(0, (await Run("prepare-config")).Code); Assert.Equal(0, (await Run("resolve-deployment")).Code);
        if (!include) return;
        Save("connection.local.json", new JsonObject { ["Id"] = "stable-db", ["Password"] = "secret-password-never-print", ["Context"] = "submitted context", ["AllowedQueries"] = new JsonArray("SELECT") });
        var cfg = Read("deployment.local.json"); cfg["ConnectionFiles"] = new JsonArray("connection.local.json"); Save("deployment.local.json", cfg);
    }
    [Fact] public async Task NoOptionalConnectionFilesRequiresNoRestServer()
    {
        await ConfigureConnection(false); Assert.Equal(0, (await Run("register", extra: ["--url", "http://127.0.0.1:1"])).Code);
    }
    [Fact] public async Task AbsoluteHostConnectionUnderPackageIsTranslatedIntoUtilityMount()
    {
        await ConfigureConnection(); var cfg = Read("deployment.local.json"); cfg["ConnectionFiles"] = new JsonArray(HostBase + "/connection.local.json"); Save("deployment.local.json", cfg);
        using var server = new RestServer(existing: true); Assert.Equal(0, (await Run("register", extra: ["--url", server.Url])).Code);
    }
    [Fact] public async Task ExternalAbsoluteConnectionPathFailsBeforeAnyNetworkRequest()
    {
        await ConfigureConnection(); var cfg = Read("deployment.local.json"); cfg["ConnectionFiles"] = new JsonArray(Path.Combine(root, "connection.local.json")); Save("deployment.local.json", cfg);
        using var server = new RestServer(); var result = await Run("register", extra: ["--url", server.Url]); Assert.Equal(1, result.Code); Assert.Empty(server.Calls);
    }
    [Fact] public async Task ExistingConnectionIsReadWithoutPostOrPutAndRetainsContext()
    {
        await ConfigureConnection(); using var server = new RestServer(existing: true);
        var result = await Run("register", extra: ["--url", server.Url, "--timeout", "2"]); Assert.Equal(0, result.Code); Assert.Empty(result.Out);
        Assert.Equal(new[] { "GET /", "GET /v1/database/stable-db" }, server.Calls.ToArray()); Assert.Equal("curated context", server.Context);
    }
    [Fact] public async Task NewConnectionWaitsForCrawlThenRunsSelectOneAndNeverLogsSecret()
    {
        await ConfigureConnection(); using var server = new RestServer();
        var result = await Run("register", extra: ["--url", server.Url, "--timeout", "2"]); Assert.Equal(0, result.Code);
        Assert.Contains("POST /v1/database", server.Calls); Assert.Contains("POST /v1/database/stable-db/query", server.Calls);
        Assert.Equal("SELECT 1 AS ok", server.Query); Assert.True(server.DatabaseGets >= 3); Assert.DoesNotContain("secret-password", result.Out + result.Err);
    }
    [Fact] public async Task ConcurrentRegistrationConflictConfirmsStableIdWithoutUpdate()
    {
        await ConfigureConnection(); using var server = new RestServer(conflict: true);
        var result = await Run("register", extra: ["--url", server.Url, "--timeout", "2"]); Assert.Equal(0, result.Code);
        Assert.Equal(new[] { "GET /", "GET /v1/database/stable-db", "POST /v1/database", "GET /v1/database/stable-db" }, server.Calls.ToArray()); Assert.Null(server.Query);
    }
    [Theory] [InlineData(401)] [InlineData(403)] [InlineData(302)]
    public async Task ReadinessErrorsNeverExposeServerBodyOrSendSecretToRedirect(int status)
    {
        await ConfigureConnection(); using var destination = new RestServer(); using var server = new RestServer(readiness: status, redirect: destination.Url);
        var result = await Run("register", extra: ["--url", server.Url, "--timeout", "1"]); Assert.Equal(1, result.Code);
        Assert.Empty(destination.Calls); Assert.DoesNotContain("secret-server-body", result.Err + result.Out);
    }
    [Theory] [InlineData(true, false)] [InlineData(false, true)]
    public async Task InvalidJsonOrFailedCrawlStopsBeforeSelectAndSanitizesError(bool invalidJson, bool failedCrawl)
    {
        await ConfigureConnection(); using var server = new RestServer(invalidJson: invalidJson, failedCrawl: failedCrawl);
        var result = await Run("register", extra: ["--url", server.Url, "--timeout", "1"]); Assert.Equal(1, result.Code); Assert.Null(server.Query);
        Assert.DoesNotContain("secret-server-body", result.Err + result.Out);
    }
    private sealed class RestServer : IDisposable
    {
        private readonly HttpListener listener = new(); private readonly Task loop;
        public ConcurrentQueue<string> Calls { get; } = new(); public string Url { get; }
        public string Context { get; private set; } = "curated context"; public string? Query { get; private set; }
        public int DatabaseGets { get; private set; }
        public RestServer(bool existing = false, bool conflict = false, int readiness = 200, string? redirect = null, bool invalidJson = false, bool failedCrawl = false)
        {
            var port = new TcpListener(IPAddress.Loopback, 0); port.Start(); var number = ((IPEndPoint)port.LocalEndpoint).Port; port.Stop();
            Url = "http://127.0.0.1:" + number; listener.Prefixes.Add(Url + "/"); listener.Start();
            loop = Task.Run(async () =>
            {
                try
                {
                    while (listener.IsListening)
                    {
                        var ctx = await listener.GetContextAsync(); string path = ctx.Request.Url!.AbsolutePath, method = ctx.Request.HttpMethod;
                        Calls.Enqueue(method + " " + path); int status = 200; JsonNode body = new JsonObject();
                        if (path == "/") { status = readiness; body = invalidJson ? new JsonArray() : new JsonObject { ["Message"] = "secret-server-body" }; if (redirect is not null) ctx.Response.RedirectLocation = redirect; }
                        else if (method == "GET")
                        {
                            DatabaseGets++; status = existing ? 200 : 404;
                            body = new JsonObject { ["DatabaseId"] = "stable-db", ["Context"] = Context, ["IsCrawled"] = !failedCrawl && DatabaseGets >= 3, ["CrawlError"] = failedCrawl ? "secret-server-body" : null };
                        }
                        else
                        {
                            using var reader = new StreamReader(ctx.Request.InputStream); var posted = JsonNode.Parse(await reader.ReadToEndAsync())!;
                            if (path == "/v1/database") { existing = true; Context = posted["Context"]!.GetValue<string>(); status = conflict ? 409 : 201; }
                            else { Query = posted["Query"]!.GetValue<string>(); body = JsonNode.Parse("""{"Success":true,"RowsReturned":1,"Data":{"Rows":[{"ok":1}]}}""")!; }
                        }
                        byte[] bytes = Encoding.UTF8.GetBytes(body.ToJsonString()); ctx.Response.StatusCode = status; ctx.Response.ContentType = "application/json"; ctx.Response.ContentLength64 = bytes.Length;
                        await ctx.Response.OutputStream.WriteAsync(bytes); ctx.Response.Close();
                    }
                }
                catch (Exception ex) when (ex is HttpListenerException or ObjectDisposedException) { }
            });
        }
        public void Dispose() { listener.Close(); loop.GetAwaiter().GetResult(); }
    }
}
