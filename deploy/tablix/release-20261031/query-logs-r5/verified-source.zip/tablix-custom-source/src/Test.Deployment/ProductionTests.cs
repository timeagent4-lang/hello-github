using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json.Nodes;
using Microsoft.Data.Sqlite;
using Tablix.Core.Persistence;
using Tablix.Core.Settings;
using Tablix.Deployment;

namespace Test.Deployment;

public sealed class ProductionTests : IDisposable
{
    private readonly string root = Path.Combine(Path.GetTempPath(), "tablix-production-" + Guid.NewGuid().ToString("N"));
    private Dictionary<string, string> Env() => new()
    {
        ["MYSQL_HOST"] = "mysql.internal", ["MYSQL_PORT"] = "3306", ["MYSQL_DATABASE"] = "business",
        ["MYSQL_USER"] = "readonly", ["MYSQL_PASSWORD"] = "quote\"slash\\dollar$'中文\nnewline",
        ["MYSQL_ID"] = "db_internal_mysql", ["TABLIX_LOG_DIRECTORY"] = Path.Combine(root, "logs")
    };
    private async Task<(int Code, string Out, string Error)> Run(string command, Dictionary<string, string>? env = null, params string[] extra)
    {
        using var output = new StringWriter(); using var error = new StringWriter();
        var code = await Program.RunAsync([command, "--base", root, "--host-base", "/data", .. extra], new StringReader(""), output, error, env ?? Env());
        return (code, output.ToString(), error.ToString());
    }
    public void Dispose() { SqliteConnection.ClearAllPools(); if (Directory.Exists(root)) Directory.Delete(root, true); }
    private JsonObject Config() => JsonNode.Parse(File.ReadAllText(Path.Combine(root, "tablix.json")))!.AsObject();
    private async Task<DatabaseDriverBase> Open() => await DatabaseDriverFactory.CreateAndInitializeAsync(new PersistenceDatabaseSettings { Filename = Path.Combine(root, "tablix.db") });

    [Fact] public async Task FreshProductionPreparesRealStateWithoutNetworkOrSeedConnectionsAndDisablesProviders()
    {
        var result = await Run("production-prepare"); Assert.Equal(0, result.Code);
        Assert.DoesNotContain(Env()["MYSQL_PASSWORD"], result.Out + result.Error);
        await using var db = await Open(); var entry = await db.DatabaseConnections.ReadAsync("db_internal_mysql");
        Assert.NotNull(entry); Assert.Equal(Env()["MYSQL_PASSWORD"], entry.Password); Assert.Equal("business", entry.Schema);
        Assert.Equal(1, await db.DatabaseConnections.CountAsync()); Assert.Equal(new[] { "SELECT" }, entry.AllowedQueries.Select(x => x.ToString()));
        using var sqlite = new SqliteConnection($"Data Source={Path.Combine(root, "tablix.db")};Pooling=False"); sqlite.Open();
        using var cmd = sqlite.CreateCommand(); cmd.CommandText = "SELECT COUNT(*) FROM model_providers WHERE enabled<>0 OR health_check_enabled<>0";
        Assert.Equal(0L, cmd.ExecuteScalar());
        var cfg = Config(); Assert.False(cfg["Chat"]!["Enabled"]!.GetValue<bool>());
        Assert.Equal("127.0.0.1", cfg["Rest"]!["Hostname"]!.GetValue<string>());
        Assert.Equal("*", cfg["Rest"]!["McpHostname"]?.GetValue<string>());
        Assert.Equal(3, cfg["Mcp"]!["DisabledTools"]!.AsArray().Count); Assert.Equal(64, cfg["ApiKeys"]![0]!.GetValue<string>().Length);
        Assert.Equal(Path.Combine(root, "tablix.db"), cfg["Persistence"]!["Filename"]!.GetValue<string>());
    }
    [Fact] public async Task RestartUpdatesEnvConnectionAndKeepsContextIdsAndGeneratedKey()
    {
        Assert.Equal(0, (await Run("production-prepare")).Code); var key = Config()["ApiKeys"]![0]!.ToString();
        await using (var db = await Open())
        {
            await db.DatabaseContexts.UpsertAsync("db_internal_mysql", "curated business context", source: "business-kb");
            await db.DatabaseConnections.CreateAsync(new DatabaseEntry { Id = "another-db", Name = "keep", Type = Tablix.Core.Enums.DatabaseTypeEnum.Mysql, Hostname = "other" });
        }
        var env = Env(); env["MYSQL_HOST"] = "new.internal"; env["MYSQL_PASSWORD"] = "rotated-password";
        Assert.Equal(0, (await Run("production-prepare", env)).Code); Assert.Equal(key, Config()["ApiKeys"]![0]!.ToString());
        await using var reopened = await Open(); var current = await reopened.DatabaseConnections.ReadAsync("db_internal_mysql");
        Assert.Equal("new.internal", current.Hostname); Assert.Equal("rotated-password", current.Password);
        Assert.Equal("curated business context", current.Context); Assert.NotNull(await reopened.DatabaseConnections.ReadAsync("another-db"));
        using var sqlite = new SqliteConnection($"Data Source={Path.Combine(root, "tablix.db")};Pooling=False"); sqlite.Open();
        using var cmd = sqlite.CreateCommand(); cmd.CommandText = "SELECT source FROM context_records WHERE database_id='db_internal_mysql'";
        Assert.Equal("business-kb", cmd.ExecuteScalar());
    }
    [Theory]
    [InlineData("MYSQL_HOST", "REPLACE_WITH_MYSQL_HOST")]
    [InlineData("MYSQL_PASSWORD", "")]
    [InlineData("MYSQL_PORT", "0")]
    [InlineData("MYSQL_ID", "../unsafe")]
    [InlineData("TABLIX_TOOL_PREFIX", "bad prefix")]
    [InlineData("TABLIX_DISABLED_TOOLS", "typo")]
    [InlineData("TABLIX_REST_API_KEY", "tablixadmin")]
    public async Task InvalidProductionEnvFailsBeforeWritingState(string key, string value)
    {
        var env = Env(); env[key] = value; var result = await Run("production-prepare", env);
        Assert.Equal(1, result.Code); Assert.False(File.Exists(Path.Combine(root, "tablix.db")));
        Assert.False(File.Exists(Path.Combine(root, "tablix.json")));
        Assert.DoesNotContain("Unknown deployment command", result.Error);
        if (env["MYSQL_PASSWORD"].Length > 0) Assert.DoesNotContain(env["MYSQL_PASSWORD"], result.Error);
    }
    [Fact] public async Task ExplicitPolicyAndApiKeyAreReadFromEnvAndPersistAcrossRestart()
    {
        var env = Env(); env["TABLIX_TOOL_PREFIX"] = "db_"; env["TABLIX_DISABLED_TOOLS"] = "update_database_context,update_table_context";
        env["TABLIX_REST_API_KEY"] = new string('a', 40);
        Assert.Equal(0, (await Run("production-prepare", env)).Code);
        Assert.Equal("db_", Config()["Mcp"]!["ToolNamePrefix"]!.ToString()); Assert.Equal(2, Config()["Mcp"]!["DisabledTools"]!.AsArray().Count);
        Assert.Equal(new string('a', 40), Config()["ApiKeys"]![0]!.ToString());
    }
    [Fact] public async Task InterruptedOldTemporaryConfigDoesNotBlockRestart()
    {
        Directory.CreateDirectory(root); File.WriteAllText(Path.Combine(root, "tablix.json.tmp"), "interrupted-write");
        var result = await Run("production-prepare"); Assert.Equal(0, result.Code);
        Assert.Equal("tablix_", Config()["Mcp"]!["ToolNamePrefix"]!.ToString());
    }
    [Theory] [InlineData(true)] [InlineData(false)]
    public async Task ProductionVerifyWaitsForCrawlAndChecksQueryWithoutLeakingServerErrors(bool validQuery)
    {
        Assert.Equal(0, (await Run("production-prepare")).Code);
        var listener = new HttpListener(); var reserve = new TcpListener(IPAddress.Loopback, 0); reserve.Start(); int port = ((IPEndPoint)reserve.LocalEndpoint).Port; reserve.Stop();
        string url = "http://127.0.0.1:" + port; listener.Prefixes.Add(url + "/"); listener.Start();
        int queries = 0, gets = 0, crawls = 0;
        var loop = Task.Run(async () =>
        {
            try
            {
                while (listener.IsListening)
                {
                    var ctx = await listener.GetContextAsync(); string path = ctx.Request.Url!.AbsolutePath;
                    string body = "{}";
                    if (path.EndsWith("/crawl")) { Interlocked.Increment(ref crawls); body = "{\"DatabaseId\":\"db_internal_mysql\",\"IsCrawled\":true,\"CrawlError\":null}"; }
                    else if (path.EndsWith("/query")) { Interlocked.Increment(ref queries); body = validQuery ? "{\"Success\":true,\"RowsReturned\":1,\"Data\":{\"Rows\":[{\"ok\":1}]}}" : "{\"Success\":false,\"Error\":\"secret server details\"}"; }
                    else if (path.Contains("/v1/database/")) { var n = Interlocked.Increment(ref gets); body = "{\"DatabaseId\":\"db_internal_mysql\",\"IsCrawled\":" + (n >= 2 ? "true" : "false") + ",\"CrawlError\":null}"; }
                    byte[] data = Encoding.UTF8.GetBytes(body); ctx.Response.ContentType = "application/json"; ctx.Response.ContentLength64 = data.Length;
                    await ctx.Response.OutputStream.WriteAsync(data); ctx.Response.Close();
                }
            } catch (Exception ex) when (ex is HttpListenerException or ObjectDisposedException) { }
        });
        try
        {
            var result = await Run("production-verify", extra: ["--url", url, "--timeout", "3"]);
            Assert.Equal(validQuery ? 0 : 1, result.Code); Assert.Equal(1, queries); Assert.Equal(1, crawls);
            Assert.DoesNotContain("secret server details", result.Error);
        }
        finally { listener.Close(); await loop; }
    }
    [Theory] [InlineData(true, false)] [InlineData(false, true)]
    public async Task ProductionReadinessUsesFreshCrawlInsteadOfOldPersistedStatus(bool persistedSuccess, bool freshSuccess)
    {
        Assert.Equal(0, (await Run("production-prepare")).Code);
        var listener = new HttpListener(); var reserve = new TcpListener(IPAddress.Loopback, 0); reserve.Start(); int port = ((IPEndPoint)reserve.LocalEndpoint).Port; reserve.Stop();
        string url = "http://127.0.0.1:" + port; listener.Prefixes.Add(url + "/"); listener.Start();
        int queryCount = 0, freshCrawls = 0;
        var loop = Task.Run(async () =>
        {
            try
            {
                while (listener.IsListening)
                {
                    var ctx = await listener.GetContextAsync(); string path = ctx.Request.Url!.AbsolutePath; string body = "{}";
                    if (path.EndsWith("/crawl"))
                    {
                        Interlocked.Increment(ref freshCrawls);
                        body = freshSuccess ? "{\"DatabaseId\":\"db_internal_mysql\",\"IsCrawled\":true,\"CrawlError\":null}" : "{\"DatabaseId\":\"db_internal_mysql\",\"IsCrawled\":false,\"CrawlError\":\"secret current schema failure\"}";
                    }
                    else if (path.EndsWith("/query")) { Interlocked.Increment(ref queryCount); body = "{\"Success\":true,\"RowsReturned\":1,\"Data\":{\"Rows\":[{\"ok\":1}]}}"; }
                    else if (path.Contains("/v1/database/")) body = persistedSuccess ? "{\"DatabaseId\":\"db_internal_mysql\",\"IsCrawled\":true}" : "{\"DatabaseId\":\"db_internal_mysql\",\"IsCrawled\":false}";
                    byte[] data = Encoding.UTF8.GetBytes(body); ctx.Response.ContentLength64 = data.Length; await ctx.Response.OutputStream.WriteAsync(data); ctx.Response.Close();
                }
            } catch (Exception ex) when (ex is HttpListenerException or ObjectDisposedException) { }
        });
        try
        {
            var result = await Run("production-verify", extra: ["--url", url, "--timeout", "1"]);
            Assert.Equal(freshSuccess ? 0 : 1, result.Code); Assert.Equal(1, freshCrawls);
            Assert.Equal(freshSuccess ? 1 : 0, queryCount); Assert.DoesNotContain("secret current schema failure", result.Error);
        }
        finally { listener.Close(); await loop; }
    }
}
